<?php
/**
 * Blog listing. Used automatically once Settings -> Reading has a static
 * "Posts page" assigned (see README) — WordPress routes that page's URL
 * here regardless of any page template, so this ignores the main query
 * and runs its own, the same way page-portfolio.php does, to keep the
 * static site's client-side filter/search/pager JS working against a
 * fully-rendered card list rather than switching to server-side paging
 * (which would break filtering across pages).
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

get_header();

$peepal_posts_page = get_option( 'page_for_posts' ) ? get_post( get_option( 'page_for_posts' ) ) : null;
$peepal_categories = get_categories( array( 'hide_empty' => true ) );

$peepal_blog_query = new WP_Query(
	array(
		'post_type'      => 'post',
		'post_status'    => 'publish',
		'posts_per_page' => 60,
	)
);
?>

<article class="frame sec sec--case">
	<nav class="cs__crumb" aria-label="Breadcrumb">
		<a href="<?php echo esc_url( home_url( '/' ) ); ?>"><?php esc_html_e( 'Home', 'peepal-design' ); ?></a> <span aria-hidden="true">/</span>
		<span aria-current="page"><?php esc_html_e( 'Insights & Blog', 'peepal-design' ); ?></span>
	</nav>

	<header class="cs__head">
		<h1 class="cs__title develop"><?php echo $peepal_posts_page ? esc_html( get_the_title( $peepal_posts_page ) ) : esc_html__( 'Notes from the field', 'peepal-design' ); ?></h1>
		<?php if ( $peepal_posts_page && has_excerpt( $peepal_posts_page ) ) : ?>
		<p class="cs__intro develop" data-delay="1"><?php echo esc_html( get_the_excerpt( $peepal_posts_page ) ); ?></p>
		<?php endif; ?>
	</header>

	<?php if ( $peepal_blog_query->have_posts() ) : ?>
	<?php
	$peepal_blog_query->the_post();
	$peepal_lead_cats = get_the_category();
	?>
	<section class="cs develop" id="lead">
		<a class="lead" href="<?php the_permalink(); ?>">
			<span class="lead__plate" aria-hidden="true">
				<?php if ( has_post_thumbnail() ) : ?>
				<?php the_post_thumbnail( 'large', array( 'class' => 'lead__img', 'fetchpriority' => 'high' ) ); ?>
				<?php endif; ?>
				<span class="lead__no">01</span>
			</span>
			<span class="lead__body">
				<span class="lead__flag"><?php esc_html_e( 'Latest', 'peepal-design' ); ?></span>
				<?php if ( $peepal_lead_cats ) : ?>
				<span class="lead__cat"><?php echo esc_html( $peepal_lead_cats[0]->name ); ?></span>
				<?php endif; ?>
				<h2 class="lead__t"><?php the_title(); ?></h2>
				<span class="lead__dek"><?php echo esc_html( get_the_excerpt() ); ?></span>
				<span class="lead__meta"><time datetime="<?php echo esc_attr( get_the_date( 'c' ) ); ?>"><?php echo esc_html( get_the_date() ); ?></time><span aria-hidden="true">&middot;</span><?php echo esc_html( peepal_read_time( get_the_ID() ) ); ?></span>
				<span class="lead__go"><?php esc_html_e( 'Read the piece', 'peepal-design' ); ?>
					<svg viewBox="0 0 16 10" aria-hidden="true"><path d="M0 5h14M10 1l4 4-4 4" fill="none" stroke="currentColor" stroke-width="1.4" stroke-linecap="round" stroke-linejoin="round"/></svg>
				</span>
			</span>
		</a>
	</section>
	<?php endif; ?>

	<section class="cs develop" id="latest">
		<?php if ( $peepal_categories ) : ?>
		<div class="jobbar">
			<ul class="filters__row jobbar__filts" id="postFilters"
					data-filters="postList" data-filter-item=".pcard" data-filter-empty="postsEmpty"
					data-page-size="6" data-pager="postPager" data-pager-noun="pieces" data-filter-search="postSearch">
				<li><button class="filt filt--chip is-on" type="button" data-cat="all" aria-pressed="true"><?php esc_html_e( 'All', 'peepal-design' ); ?></button></li>
				<?php foreach ( $peepal_categories as $peepal_category ) : ?>
				<li><button class="filt filt--chip" type="button" data-cat="<?php echo esc_attr( $peepal_category->slug ); ?>" aria-pressed="false"><?php echo esc_html( $peepal_category->name ); ?></button></li>
				<?php endforeach; ?>
			</ul>
			<div class="jobsearch">
				<label class="vh" for="postSearch"><?php esc_html_e( 'Search the writing', 'peepal-design' ); ?></label>
				<svg class="jobsearch__ico" viewBox="0 0 18 18" aria-hidden="true"><circle cx="8" cy="8" r="5.4" fill="none" stroke="currentColor" stroke-width="1.5"/><path d="M12.2 12.2 16 16" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"/></svg>
				<input class="jobsearch__in" id="postSearch" type="search" placeholder="<?php esc_attr_e( 'Search titles', 'peepal-design' ); ?>">
			</div>
		</div>
		<?php endif; ?>

		<div class="pgrid pgrid--3" id="postList">
			<?php
			$peepal_index = 1; // 01 was the lead post above; the grid continues from 02.
			while ( $peepal_blog_query->have_posts() ) :
				$peepal_blog_query->the_post();
				++$peepal_index;
				$peepal_card_cats = get_the_category();
				?>
			<article class="pcard" data-cats="<?php echo esc_attr( implode( ' ', wp_list_pluck( $peepal_card_cats, 'slug' ) ) ); ?>">
				<span class="pplate" aria-hidden="true">
					<?php if ( has_post_thumbnail() ) : ?>
					<?php the_post_thumbnail( 'peepal-card', array( 'class' => 'pplate__img' ) ); ?>
					<?php endif; ?>
					<span class="pplate__no"><?php echo esc_html( sprintf( '%02d', $peepal_index ) ); ?></span>
				</span>
				<div class="pcard__body">
					<?php if ( $peepal_card_cats ) : ?>
					<span class="pcard__cat"><?php echo esc_html( $peepal_card_cats[0]->name ); ?></span>
					<?php endif; ?>
					<h3 class="pcard__t"><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h3>
					<p class="pcard__dek"><?php echo esc_html( get_the_excerpt() ); ?></p>
					<p class="pcard__meta"><time datetime="<?php echo esc_attr( get_the_date( 'c' ) ); ?>"><?php echo esc_html( get_the_date() ); ?></time><span aria-hidden="true">&middot;</span><?php echo esc_html( peepal_read_time( get_the_ID() ) ); ?></p>
				</div>
			</article>
			<?php endwhile; ?>
		</div>
		<nav class="pager" id="postPager" aria-label="<?php esc_attr_e( 'Writing pages', 'peepal-design' ); ?>"></nav>
		<p class="jobs__empty" id="postsEmpty" hidden><?php esc_html_e( 'Nothing on', 'peepal-design' ); ?> <span data-empty-term><?php esc_html_e( 'this subject', 'peepal-design' ); ?></span> <?php esc_html_e( 'yet.', 'peepal-design' ); ?> <a href="<?php echo esc_url( home_url( '/blog/' ) ); ?>"><?php esc_html_e( 'See everything', 'peepal-design' ); ?></a> <?php esc_html_e( 'instead.', 'peepal-design' ); ?></p>
	</section>
	<?php wp_reset_postdata(); ?>
</article>

<section class="frame sec sec--pitch" id="subscribe">
	<div class="pitch">
		<h2 class="pitch__h develop"><?php esc_html_e( 'One email, when there is something to say', 'peepal-design' ); ?></h2>
		<p class="pitch__p develop" data-delay="1"><?php esc_html_e( 'New writing, and the occasional thing we only send to the list. No cadence promised — we would rather be worth opening than punctual.', 'peepal-design' ); ?></p>

		<form class="signup develop" data-signup data-delay="2" action="<?php echo esc_url( home_url( '/#contact' ) ); ?>" method="get" novalidate>
			<label class="vh" for="signupEmail"><?php esc_html_e( 'Email address', 'peepal-design' ); ?></label>
			<input class="signup__in" id="signupEmail" name="email" type="email"
						 placeholder="<?php esc_attr_e( 'Email address', 'peepal-design' ); ?>" autocomplete="email" required
						 aria-describedby="signupMsg">
			<button class="btn btn--mark signup__go" type="submit"><?php esc_html_e( 'Subscribe', 'peepal-design' ); ?></button>
			<p class="signup__msg" id="signupMsg" role="status" aria-live="polite"></p>
		</form>
	</div>
</section>

<?php get_footer(); ?>
