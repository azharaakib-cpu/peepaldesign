<?php
/**
 * Template Name: Our Journey
 *
 * A one-off narrative page: hero carousel + a fully flexible body
 * (About/Values as plain heading-only sections, Beliefs as a 2-up .lvls
 * grid, "Meet the leaders" as a crew grid) authored with Block Patterns,
 * same mechanism as Service/Case Study/Training bodies.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

get_header();

while ( have_posts() ) :
	the_post();
	?>

<article class="frame sec sec--case">
	<nav class="cs__crumb" aria-label="Breadcrumb">
		<a href="<?php echo esc_url( home_url( '/' ) ); ?>"><?php esc_html_e( 'Home', 'peepal-design' ); ?></a> <span aria-hidden="true">/</span>
		<a href="<?php echo esc_url( home_url( '/#global' ) ); ?>"><?php esc_html_e( 'Our Story', 'peepal-design' ); ?></a> <span aria-hidden="true">/</span>
		<span aria-current="page"><?php the_title(); ?></span>
	</nav>

	<header class="cs__head">
		<h1 class="cs__title develop"><?php the_title(); ?></h1>
		<?php if ( has_excerpt() ) : ?>
		<p class="cs__intro develop" data-delay="1"><?php echo esc_html( get_the_excerpt() ); ?></p>
		<?php endif; ?>
	</header>

	<?php
	get_template_part(
		'template-parts/hero-carousel',
		null,
		array(
			'images' => array( 'ourstory/hero-1.jpeg', 'ourstory/hero-2.jpeg', 'ourstory/hero-3.jpeg', 'ourstory/hero-4.jpeg' ),
			'label'  => __( 'Sixteen years of Peepal Design', 'peepal-design' ),
		)
	);
	?>

	<?php the_content(); ?>
</article>

<?php get_template_part( 'template-parts/pitch-cta' ); ?>

<?php
endwhile;

get_footer();
