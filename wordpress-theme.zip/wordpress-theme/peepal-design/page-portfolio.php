<?php
/**
 * Template Name: Portfolio
 *
 * The case-studies grid with filter chips. Assign this template to the
 * Page at slug "portfolio" (header.php's mega-menu links straight to
 * home_url('/portfolio/')). Filter chips are built from whatever
 * case_category terms actually exist, rather than the static site's
 * hardcoded list — add or rename a term in wp-admin and the chip row
 * follows automatically.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

get_header();

$peepal_categories = get_terms(
	array(
		'taxonomy'   => 'case_category',
		'hide_empty' => true,
	)
);
if ( ! is_array( $peepal_categories ) ) {
	$peepal_categories = array();
}

$peepal_cases_query = new WP_Query(
	array(
		'post_type'      => 'case_study',
		'post_status'    => 'publish',
		'posts_per_page' => -1,
		'orderby'        => 'menu_order date',
		'order'          => 'ASC',
	)
);
?>

<section class="frame hero hero--page" id="hero">
  <div class="hero__vignette" aria-hidden="true"></div>
  <div class="hero__inner">
    <?php if ( have_posts() ) : the_post(); ?>
    <h1 class="hero__h1 develop"><?php the_title(); ?></h1>
    <?php if ( has_excerpt() ) : ?>
    <p class="hero__sub develop" data-delay="1"><?php echo esc_html( get_the_excerpt() ); ?></p>
    <?php endif; ?>
    <?php else : ?>
    <h1 class="hero__h1 develop">Designing across <em class="hero__em">AI Maturity Curve</em></h1>
    <p class="hero__sub develop" data-delay="1"><?php esc_html_e( 'Every case study here starts the same way, with people. We research first, design second. Browse our work across industries, service types, and business challenges.', 'peepal-design' ); ?></p>
    <?php endif; ?>
  </div>
</section>

<section class="frame sec sec--cases" id="cases">
  <?php if ( $peepal_categories ) : ?>
  <nav class="filters develop" aria-label="<?php esc_attr_e( 'Filter case studies', 'peepal-design' ); ?>">
    <ul class="filters__row filters__row--chips" id="caseFilters" data-filters="caseList" data-filter-item=".case" data-filter-empty="casesEmpty">
      <li><button class="filt filt--chip is-on" type="button" data-cat="all" aria-pressed="true"><?php esc_html_e( 'All Case Studies', 'peepal-design' ); ?></button></li>
      <?php foreach ( $peepal_categories as $peepal_term ) : ?>
      <li><button class="filt filt--chip" type="button" data-cat="<?php echo esc_attr( $peepal_term->slug ); ?>" aria-pressed="false"><?php echo esc_html( $peepal_term->name ); ?></button></li>
      <?php endforeach; ?>
    </ul>
  </nav>
  <?php endif; ?>

  <div class="cases" id="caseList">
    <?php
    $peepal_index = 0;
    while ( $peepal_cases_query->have_posts() ) :
        $peepal_cases_query->the_post();
        ++$peepal_index;
        get_template_part(
            'template-parts/case-card',
            null,
            array(
                'prefix' => 'P',
                'index'  => $peepal_index,
            )
        );
    endwhile;
    wp_reset_postdata();
    ?>
  </div>

  <p class="cases__empty" id="casesEmpty" hidden>
    <span class="cases__empty-code"><?php esc_html_e( 'NOTHING FILED HERE YET', 'peepal-design' ); ?></span>
    <?php esc_html_e( 'No case study carries this tag so far.', 'peepal-design' ); ?> <button class="cases__reset" type="button"><?php esc_html_e( 'Show all case studies', 'peepal-design' ); ?></button>
  </p>
</section>

<?php get_template_part( 'template-parts/pitch-cta' ); ?>

<?php get_footer(); ?>
