<?php
/**
 * Header: skip link, the two full-bleed background layers, the mega-menu
 * nav, and the mobile menu drawer. Ported near-verbatim from the static
 * site (every page carried byte-identical copies of this markup) — see
 * inc/theme-setup.php for why the mega-menu is hand-authored rather than
 * wp_nav_menu()-driven, and inc/template-tags.php for the is-here/
 * aria-current active-state helpers used throughout.
 *
 * Permalink conventions this menu assumes (set up by the relevant CPT's
 * register_post_type() call, added in later phases):
 *   Service        /services/{slug}/        (slug = static filename minus "service-")
 *   Training       /trainings/{slug}/        (slug = static filename minus "training-")
 *   Case study     /case-studies/{slug}/
 *   Portfolio      /portfolio/                (a Page)
 *   Careers        /careers/                  (a Page)
 *   Our Journey    /our-journey/               (a Page)
 *   Our Global Family /our-global-family/      (a Page)
 *   Blog           /blog/                      (Settings > Reading > Posts page)
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$peepal_assets = PEEPAL_THEME_URI . '/assets';
?>
<!doctype html>
<html lang="<?php bloginfo( 'language' ); ?>" class="no-js <?php echo esc_attr( implode( ' ', get_body_class() ) ); ?>">
<head>
<meta charset="<?php bloginfo( 'charset' ); ?>">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="theme-color" content="#0B0B0C">
<script>document.documentElement.className = document.documentElement.className.replace('no-js','js');</script>
<?php wp_head(); ?>
</head>
<body <?php body_class(); ?>>
<?php wp_body_open(); ?>

<a class="skip" href="#top">Skip to content</a>

<div class="bgwash" id="bgWash" aria-hidden="true"></div>
<div class="grain" aria-hidden="true"></div>

<header class="nav" id="nav">
  <div class="nav__inner">
    <a class="logo" href="<?php echo esc_url( home_url( '/' ) ); ?>" aria-label="<?php esc_attr_e( 'Peepal Design home', 'peepal-design' ); ?>">
      <img class="logo__mark" src="<?php echo esc_url( $peepal_assets . '/brand/logomark.svg' ); ?>" alt="" width="26" height="26"
           onerror="this.onerror=null;this.src='<?php echo esc_url( $peepal_assets . '/brand/logomark.png' ); ?>'">
      <span class="logo__word">peepaldesign</span>
    </a>
    <nav class="nav__menu" aria-label="Primary">
      <div class="nav__item nav__item--mega has-menu">
        <button class="nav__link" aria-expanded="false" aria-controls="m-services">Our Services<svg class="caret" viewBox="0 0 10 6" aria-hidden="true"><path d="M1 1l4 4 4-4" fill="none" stroke="currentColor" stroke-width="1.3" stroke-linecap="round"/></svg></button>
        <div class="dropdown dropdown--panel dropdown--panel-wide" id="m-services" hidden>
          <div class="mega">
            <div class="mega__col">
              <span class="mega__head">User Research Services</span>
              <?php
              $peepal_research_services = array(
                  'quantitative-qualitative-research' => 'Quantitative and Qualitative research',
                  'usability-testing'                 => 'Usability Testing',
                  'ux-benchmarking'                    => 'UX Benchmarking - UX Index',
                  'ai-opportunity-mapping'              => 'AI Opportunity Mapping',
              );
              foreach ( $peepal_research_services as $peepal_slug => $peepal_title ) :
                  $peepal_path = '/services/' . $peepal_slug . '/';
                  ?>
              <a class="megaitem megaitem--compact<?php peepal_nav_class( $peepal_path ); ?>"<?php peepal_nav_aria_current( $peepal_path ); ?> href="<?php echo esc_url( home_url( $peepal_path ) ); ?>"><span class="megaitem__dot" aria-hidden="true"></span><span class="megaitem__body"><span class="megaitem__title"><?php echo esc_html( $peepal_title ); ?></span></span><svg class="megaitem__arrow" viewBox="0 0 16 10" aria-hidden="true"><path d="M0 5h14M10 1l4 4-4 4" fill="none" stroke="currentColor" stroke-width="1.4" stroke-linecap="round" stroke-linejoin="round"/></svg></a>
              <?php endforeach; ?>
            </div>
            <div class="mega__col">
              <span class="mega__head">Design Services</span>
              <?php
              $peepal_design_services = array(
                  'ux-ui-design'              => 'UX-UI Design',
                  'service-design'            => 'Service Design',
                  'ux-for-ai-product'         => 'UX for AI Product',
                  'conversational-ai-ux'      => 'Conversational AI - UX Design',
                  'ai-product-prototyping'    => 'AI Product Prototyping',
                  'design-accessibility'      => 'Design for Accessibility',
                  'design-systems'            => 'Design Systems',
                  'data-visualisation'        => 'Data Visualisation',
              );
              foreach ( $peepal_design_services as $peepal_slug => $peepal_title ) :
                  $peepal_path = '/services/' . $peepal_slug . '/';
                  ?>
              <a class="megaitem megaitem--compact<?php peepal_nav_class( $peepal_path ); ?>"<?php peepal_nav_aria_current( $peepal_path ); ?> href="<?php echo esc_url( home_url( $peepal_path ) ); ?>"><span class="megaitem__dot" aria-hidden="true"></span><span class="megaitem__body"><span class="megaitem__title"><?php echo esc_html( $peepal_title ); ?></span></span><svg class="megaitem__arrow" viewBox="0 0 16 10" aria-hidden="true"><path d="M0 5h14M10 1l4 4-4 4" fill="none" stroke="currentColor" stroke-width="1.4" stroke-linecap="round" stroke-linejoin="round"/></svg></a>
              <?php endforeach; ?>
            </div>
            <div class="mega__col">
              <span class="mega__head">Value Added Services</span>
              <?php
              $peepal_value_services = array(
                  'ux-team-augmentation'     => 'UX Team Augmentation',
                  'design-thinking-workshop' => 'Design Thinking Workshop',
                  'ux-audit'                 => 'UX Audit',
              );
              foreach ( $peepal_value_services as $peepal_slug => $peepal_title ) :
                  $peepal_path = '/services/' . $peepal_slug . '/';
                  ?>
              <a class="megaitem megaitem--compact<?php peepal_nav_class( $peepal_path ); ?>"<?php peepal_nav_aria_current( $peepal_path ); ?> href="<?php echo esc_url( home_url( $peepal_path ) ); ?>"><span class="megaitem__dot" aria-hidden="true"></span><span class="megaitem__body"><span class="megaitem__title"><?php echo esc_html( $peepal_title ); ?></span></span><svg class="megaitem__arrow" viewBox="0 0 16 10" aria-hidden="true"><path d="M0 5h14M10 1l4 4-4 4" fill="none" stroke="currentColor" stroke-width="1.4" stroke-linecap="round" stroke-linejoin="round"/></svg></a>
              <?php endforeach; ?>
            </div>
            <a class="mega__promo" href="<?php echo esc_url( home_url( '/#services' ) ); ?>"><img src="<?php echo esc_url( $peepal_assets . '/img/services/research.jpg' ); ?>" alt="" width="896" height="1200" loading="lazy" decoding="async"><span class="mega__promo-body"><span class="mega__promo-title">Research that reveals what users actually need</span><span class="learn">Explore<svg viewBox="0 0 16 10" aria-hidden="true"><path d="M0 5h14M10 1l4 4-4 4" fill="none" stroke="currentColor" stroke-width="1.4" stroke-linecap="round" stroke-linejoin="round"/></svg></span></span></a>
          </div>
        </div>
      </div>
      <div class="nav__item"><a class="nav__link<?php peepal_nav_class( '/portfolio/' ); ?>"<?php peepal_nav_aria_current( '/portfolio/' ); ?> href="<?php echo esc_url( home_url( '/portfolio/' ) ); ?>">Portfolio</a></div>
      <div class="nav__item nav__item--mega has-menu">
        <button class="nav__link" aria-expanded="false" aria-controls="m-training">Trainings<svg class="caret" viewBox="0 0 10 6" aria-hidden="true"><path d="M1 1l4 4 4-4" fill="none" stroke="currentColor" stroke-width="1.3" stroke-linecap="round"/></svg></button>
        <div class="dropdown dropdown--panel" id="m-training" hidden>
          <div class="mega mega--list">
            <div class="mega__list">
              <?php
              $peepal_trainings = array(
                  array( 'path' => '/trainings/uxpm/', 'title' => 'UX-PM level 1-2-3', 'desc' => 'For product managers' ),
                  array( 'path' => '/trainings/researchops/', 'title' => 'Research Ops', 'desc' => 'Scale your research practice' ),
                  array( 'path' => '/trainings/design-leaders/', 'title' => 'Design Leaders Masterclass', 'desc' => 'Lead with design thinking' ),
                  array( 'path' => '/services/ux-maturity-model/', 'title' => 'UX Maturity Model', 'desc' => 'Assess &amp; elevate your org' ),
              );
              foreach ( $peepal_trainings as $peepal_item ) :
                  ?>
              <a class="megaitem<?php peepal_nav_class( $peepal_item['path'] ); ?>"<?php peepal_nav_aria_current( $peepal_item['path'] ); ?> href="<?php echo esc_url( home_url( $peepal_item['path'] ) ); ?>"><span class="megaitem__dot" aria-hidden="true"></span><span class="megaitem__body"><span class="megaitem__title"><?php echo esc_html( $peepal_item['title'] ); ?></span><span class="megaitem__desc"><?php echo wp_kses_post( $peepal_item['desc'] ); ?></span></span><svg class="megaitem__arrow" viewBox="0 0 16 10" aria-hidden="true"><path d="M0 5h14M10 1l4 4-4 4" fill="none" stroke="currentColor" stroke-width="1.4" stroke-linecap="round" stroke-linejoin="round"/></svg></a>
              <?php endforeach; ?>
            </div>
            <a class="mega__promo" href="<?php echo esc_url( home_url( '/#services' ) ); ?>"><img src="<?php echo esc_url( $peepal_assets . '/img/services/training.jpg' ); ?>" alt="" width="896" height="1200" loading="lazy" decoding="async"><span class="mega__promo-body"><span class="mega__promo-title">Build PM skills grounded in UX</span><span class="learn">Explore<svg viewBox="0 0 16 10" aria-hidden="true"><path d="M0 5h14M10 1l4 4-4 4" fill="none" stroke="currentColor" stroke-width="1.4" stroke-linecap="round" stroke-linejoin="round"/></svg></span></span></a>
          </div>
        </div>
      </div>
      <div class="nav__item nav__item--mega has-menu">
        <button class="nav__link" aria-expanded="false" aria-controls="m-story">Our Story<svg class="caret" viewBox="0 0 10 6" aria-hidden="true"><path d="M1 1l4 4 4-4" fill="none" stroke="currentColor" stroke-width="1.3" stroke-linecap="round"/></svg></button>
        <div class="dropdown dropdown--panel" id="m-story" hidden>
          <div class="mega mega--list">
            <div class="mega__list">
              <?php
              $peepal_story_items = array(
                  array( 'path' => '/our-journey/', 'title' => 'Our Journey', 'desc' => '18 years of design' ),
                  array( 'path' => '/our-global-family/', 'title' => 'Our Global Family', 'desc' => 'Meet the team' ),
                  array( 'path' => '/careers/', 'title' => 'Careers', 'desc' => 'Join us' ),
                  array( 'path' => '/blog/', 'title' => 'Blogs', 'desc' => 'Insights &amp; thinking' ),
              );
              foreach ( $peepal_story_items as $peepal_item ) :
                  ?>
              <a class="megaitem<?php peepal_nav_class( $peepal_item['path'] ); ?>"<?php peepal_nav_aria_current( $peepal_item['path'] ); ?> href="<?php echo esc_url( home_url( $peepal_item['path'] ) ); ?>"><span class="megaitem__dot" aria-hidden="true"></span><span class="megaitem__body"><span class="megaitem__title"><?php echo esc_html( $peepal_item['title'] ); ?></span><span class="megaitem__desc"><?php echo wp_kses_post( $peepal_item['desc'] ); ?></span></span><svg class="megaitem__arrow" viewBox="0 0 16 10" aria-hidden="true"><path d="M0 5h14M10 1l4 4-4 4" fill="none" stroke="currentColor" stroke-width="1.4" stroke-linecap="round" stroke-linejoin="round"/></svg></a>
              <?php endforeach; ?>
            </div>
            <a class="mega__promo" href="<?php echo esc_url( home_url( '/#global' ) ); ?>"><img src="<?php echo esc_url( $peepal_assets . '/img/services/design.jpg' ); ?>" alt="" width="896" height="1200" loading="lazy" decoding="async"><span class="mega__promo-body"><span class="mega__promo-title">From pixels to AI — our story</span><span class="learn">Explore<svg viewBox="0 0 16 10" aria-hidden="true"><path d="M0 5h14M10 1l4 4-4 4" fill="none" stroke="currentColor" stroke-width="1.4" stroke-linecap="round" stroke-linejoin="round"/></svg></span></span></a>
          </div>
        </div>
      </div>
    </nav>

    <a class="btn btn--mark nav__cta" href="<?php echo esc_url( home_url( '/#contact' ) ); ?>">Get in touch</a>

    <button class="burger" id="burger" aria-expanded="false" aria-controls="mobileMenu" aria-label="Open menu">
      <span></span><span></span>
    </button>
  </div>
</header>
<div class="nav__progress" id="navProgress" aria-hidden="true"></div>

<div class="mobilemenu" id="mobileMenu" hidden>
  <a class="mm__link" href="<?php echo esc_url( home_url( '/portfolio/' ) ); ?>">Portfolio</a>
  <div class="mm__group">
    <button class="mm__toggle" type="button" aria-expanded="false" aria-controls="mm-services">Our Services<svg class="mm__chev" viewBox="0 0 10 6" aria-hidden="true"><path d="M1 1l4 4 4-4" fill="none" stroke="currentColor" stroke-width="1.4" stroke-linecap="round"/></svg></button>
    <div class="mm__panel" id="mm-services" hidden>
    <span class="mm__head">User Research Services</span>
    <?php foreach ( $peepal_research_services as $peepal_slug => $peepal_title ) : $peepal_path = '/services/' . $peepal_slug . '/'; ?>
    <a class="mm__sub<?php peepal_nav_class( $peepal_path ); ?>"<?php peepal_nav_aria_current( $peepal_path ); ?> href="<?php echo esc_url( home_url( $peepal_path ) ); ?>"><span class="mm__subt"><?php echo esc_html( $peepal_title ); ?></span></a>
    <?php endforeach; ?>
    <span class="mm__head">Design Services</span>
    <?php foreach ( $peepal_design_services as $peepal_slug => $peepal_title ) : $peepal_path = '/services/' . $peepal_slug . '/'; ?>
    <a class="mm__sub<?php peepal_nav_class( $peepal_path ); ?>"<?php peepal_nav_aria_current( $peepal_path ); ?> href="<?php echo esc_url( home_url( $peepal_path ) ); ?>"><span class="mm__subt"><?php echo esc_html( $peepal_title ); ?></span></a>
    <?php endforeach; ?>
    <span class="mm__head">Value Added Services</span>
    <?php foreach ( $peepal_value_services as $peepal_slug => $peepal_title ) : $peepal_path = '/services/' . $peepal_slug . '/'; ?>
    <a class="mm__sub<?php peepal_nav_class( $peepal_path ); ?>"<?php peepal_nav_aria_current( $peepal_path ); ?> href="<?php echo esc_url( home_url( $peepal_path ) ); ?>"><span class="mm__subt"><?php echo esc_html( $peepal_title ); ?></span></a>
    <?php endforeach; ?>
    </div>
  </div>
  <div class="mm__group">
    <button class="mm__toggle" type="button" aria-expanded="false" aria-controls="mm-training">Trainings<svg class="mm__chev" viewBox="0 0 10 6" aria-hidden="true"><path d="M1 1l4 4 4-4" fill="none" stroke="currentColor" stroke-width="1.4" stroke-linecap="round"/></svg></button>
    <div class="mm__panel" id="mm-training" hidden>
    <?php foreach ( $peepal_trainings as $peepal_item ) : ?>
    <a class="mm__sub<?php peepal_nav_class( $peepal_item['path'] ); ?>"<?php peepal_nav_aria_current( $peepal_item['path'] ); ?> href="<?php echo esc_url( home_url( $peepal_item['path'] ) ); ?>"><span class="mm__subt"><?php echo esc_html( $peepal_item['title'] ); ?></span><span class="mm__subd"><?php echo wp_kses_post( $peepal_item['desc'] ); ?></span></a>
    <?php endforeach; ?>
    </div>
  </div>
  <div class="mm__group">
    <button class="mm__toggle" type="button" aria-expanded="false" aria-controls="mm-story">Our Story<svg class="mm__chev" viewBox="0 0 10 6" aria-hidden="true"><path d="M1 1l4 4 4-4" fill="none" stroke="currentColor" stroke-width="1.4" stroke-linecap="round"/></svg></button>
    <div class="mm__panel" id="mm-story" hidden>
    <?php foreach ( $peepal_story_items as $peepal_item ) : ?>
    <a class="mm__sub<?php peepal_nav_class( $peepal_item['path'] ); ?>"<?php peepal_nav_aria_current( $peepal_item['path'] ); ?> href="<?php echo esc_url( home_url( $peepal_item['path'] ) ); ?>"><span class="mm__subt"><?php echo esc_html( $peepal_item['title'] ); ?></span><span class="mm__subd"><?php echo wp_kses_post( $peepal_item['desc'] ); ?></span></a>
    <?php endforeach; ?>
    </div>
  </div>
  <a class="mm__link" href="<?php echo esc_url( home_url( '/#faq' ) ); ?>">FAQ</a>
  <a class="btn btn--mark mm__cta" href="<?php echo esc_url( home_url( '/#contact' ) ); ?>">Get in touch</a>
</div>

<main id="top">
