<?php
/**
 * Fallback template — WordPress requires every theme to have one, and it
 * catches any route not yet covered by a more specific template as the
 * migration proceeds through later phases.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

get_header();
?>

<article class="frame sec sec--case">
	<div class="cs__head">
		<?php if ( have_posts() ) : ?>
			<?php while ( have_posts() ) : the_post(); ?>
				<h1 class="cs__title"><?php the_title(); ?></h1>
				<div class="cs__body"><?php the_content(); ?></div>
			<?php endwhile; ?>
		<?php else : ?>
			<h1 class="cs__title"><?php esc_html_e( 'Nothing found', 'peepal-design' ); ?></h1>
		<?php endif; ?>
	</div>
</article>

<?php
get_footer();
