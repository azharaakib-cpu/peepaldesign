<?php
/**
 * Peepal Design theme bootstrap.
 *
 * Kept deliberately thin — every concern lives in its own file under inc/
 * so the CPTs, patterns and template tags stay easy to find and to touch
 * independently as the migration from the static site continues.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

define( 'PEEPAL_THEME_VERSION', '1.0.0' );
define( 'PEEPAL_THEME_DIR', get_template_directory() );
define( 'PEEPAL_THEME_URI', get_template_directory_uri() );

$peepal_includes = array(
	'inc/theme-setup.php',
	'inc/enqueue.php',
	'inc/template-tags.php',
	'inc/block-patterns.php',
	'inc/meta-boxes.php',
	'inc/cpt-service.php',
	'inc/cpt-case-study.php',
	'inc/cpt-training.php',
	'inc/cpt-job-opening.php',
	'inc/cpt-testimonial.php',
	'inc/cpt-client-logo.php',
	'inc/cpt-office.php',
	'inc/front-page-fields.php',
	// No cpt-team-member.php: team/trainer photo grids turned out to need a
	// different curated lineup on every page they appear on (Our Journey's
	// leaders vs. each training's own trainers), so they're authored with
	// the peepal/crew-grid Block Pattern instead of a shared CPT query —
	// see inc/block-patterns.php.
);

foreach ( $peepal_includes as $peepal_include ) {
	$peepal_include_path = PEEPAL_THEME_DIR . '/' . $peepal_include;
	if ( file_exists( $peepal_include_path ) ) {
		require_once $peepal_include_path;
	}
}
unset( $peepal_includes, $peepal_include, $peepal_include_path );
