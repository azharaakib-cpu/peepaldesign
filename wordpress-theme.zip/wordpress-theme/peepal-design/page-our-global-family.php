<?php
/**
 * Template Name: Our Global Family
 *
 * Hero image (the world map graphic), a fully flexible body for the
 * "network" and "beyond" narrative sections (Block Patterns, same
 * mechanism as everywhere else), and the "cities" office grid pulled
 * from the office CPT (template-parts/office-grid.php) inserted between
 * them — that grid isn't part of post_content because it's a genuine
 * queried list, not hand-authored per-page copy.
 *
 * Content authors: the office grid always renders directly after
 * whatever's in the body — if you need it to sit between two specific
 * sections, that ordering is fixed here in the template, not editable
 * from the post content.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

get_header();

while ( have_posts() ) :
	the_post();
	?>

<article class="frame sec sec--case">
	<nav class="cs__crumb" aria-label="Breadcrumb">
		<a href="<?php echo esc_url( home_url( '/' ) ); ?>"><?php esc_html_e( 'Home', 'peepal-design' ); ?></a> <span aria-hidden="true">/</span>
		<a href="<?php echo esc_url( home_url( '/#global' ) ); ?>"><?php esc_html_e( 'Our Story', 'peepal-design' ); ?></a> <span aria-hidden="true">/</span>
		<span aria-current="page"><?php the_title(); ?></span>
	</nav>

	<header class="cs__head">
		<h1 class="cs__title develop"><?php the_title(); ?></h1>
		<?php if ( has_excerpt() ) : ?>
		<p class="cs__intro develop" data-delay="1"><?php echo esc_html( get_the_excerpt() ); ?></p>
		<?php endif; ?>
	</header>

	<?php if ( has_post_thumbnail() ) : ?>
	<figure class="bleed">
		<?php the_post_thumbnail( 'peepal-hero', array( 'class' => 'bleed__img' ) ); ?>
	</figure>
	<?php endif; ?>

	<?php the_content(); ?>

	<section class="cs develop" id="cities">
		<header class="secthead" data-drift>
			<span class="secthead__over"><?php esc_html_e( 'Our offices', 'peepal-design' ); ?></span>
			<h2 class="secthead__h"><?php esc_html_e( 'Seven cities, one network', 'peepal-design' ); ?></h2>
		</header>
		<?php get_template_part( 'template-parts/office-grid' ); ?>
	</section>
</article>

<?php get_template_part( 'template-parts/pitch-cta' ); ?>

<?php
endwhile;

get_footer();
