<?php
/**
 * Template Name: Careers
 *
 * The hero carousel, "Peepal advantage" cards and application-process
 * steps are fixed brand messaging that rarely changes, so — like
 * our-journey/our-global-family — they're hardcoded here rather than
 * pulled from fields. Only the jobs list is genuinely dynamic, queried
 * from the job_opening CPT. The job-detail modal and its apply form have
 * no backend on the static site (an explicit, deliberate choice recorded
 * in a code comment there) and are reproduced exactly as inert here —
 * see the note above the modal markup below.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$peepal_assets = PEEPAL_THEME_URI . '/assets';

$peepal_functions = get_terms(
	array(
		'taxonomy'   => 'job_function',
		'hide_empty' => true,
	)
);
if ( ! is_array( $peepal_functions ) ) {
	$peepal_functions = array();
}

$peepal_jobs_query = new WP_Query(
	array(
		'post_type'      => 'job_opening',
		'post_status'    => 'publish',
		'posts_per_page' => -1,
		'orderby'        => 'menu_order date',
		'order'          => 'ASC',
	)
);

/**
 * The job-detail modal is careers-page chrome, not something footer.php
 * (shared by every page) should carry — hooking it onto wp_footer keeps
 * it out of every other page's markup while still landing before
 * </body>, same as the static site's own placement just before <footer>.
 */
add_action(
	'wp_footer',
	function () use ( $peepal_jobs_query ) {
		?>
<!-- One sheet, filled on open from the clicked role's <template class="jd__src">.
     The CV drop zone accepts and validates a real file but sends nothing:
     there is no endpoint behind it, matching the static site's own
     deliberate choice not to silently swallow an application. -->
<div class="sheet" data-sheet="job" hidden>
  <div class="sheet__scrim" data-sheet-close></div>
  <div class="sheet__panel" role="dialog" aria-modal="true" aria-labelledby="jobSheetH">
    <div class="sheet__head">
      <div>
        <p class="sheet__over" data-job-fn><?php esc_html_e( 'Open role', 'peepal-design' ); ?></p>
        <h2 class="sheet__h" id="jobSheetH" data-job-title><?php esc_html_e( 'Role', 'peepal-design' ); ?></h2>
        <p class="jd__meta" data-job-meta></p>
      </div>
      <button class="sheet__x" type="button" data-sheet-close data-sheet-focus aria-label="<?php esc_attr_e( 'Close', 'peepal-design' ); ?>">
        <svg viewBox="0 0 16 16" aria-hidden="true"><path d="M2 2l12 12M14 2L2 14" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round"/></svg>
      </button>
    </div>
    <div class="sheet__panels">
      <div class="jd">
        <div class="jd__body" data-job-body></div>
        <aside class="jd__apply">
          <h3 class="jd__applyh"><?php esc_html_e( 'Apply for this role', 'peepal-design' ); ?></h3>
          <form class="fields fields--apply" data-apply novalidate>
            <label class="fld"><span class="fld__l"><?php esc_html_e( 'Your name', 'peepal-design' ); ?> <span class="req">*</span></span>
              <input class="fld__i" name="name" type="text" autocomplete="name" required></label>
            <label class="fld"><span class="fld__l"><?php esc_html_e( 'Email', 'peepal-design' ); ?> <span class="req">*</span></span>
              <input class="fld__i" name="email" type="email" autocomplete="email" required></label>
            <label class="fld"><span class="fld__l"><?php esc_html_e( 'Portfolio or LinkedIn', 'peepal-design' ); ?></span>
              <input class="fld__i" name="portfolio" type="url" inputmode="url" placeholder="https://"></label>
            <div class="fld">
              <span class="fld__l" id="cvLabel"><?php esc_html_e( 'Your CV', 'peepal-design' ); ?> <span class="req">*</span></span>
              <div class="drop" data-drop>
                <input class="drop__in" id="jobCv" name="cv" type="file"
                       accept=".pdf,.doc,.docx,application/pdf" aria-labelledby="cvLabel" required>
                <label class="drop__face" for="jobCv">
                  <svg class="drop__ico" viewBox="0 0 24 24" aria-hidden="true">
                    <path d="M12 16V4m0 0L7.5 8.5M12 4l4.5 4.5" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
                    <path d="M4 15v3.5A1.5 1.5 0 0 0 5.5 20h13a1.5 1.5 0 0 0 1.5-1.5V15" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"/>
                  </svg>
                  <span class="drop__t"><?php esc_html_e( 'Drop your CV here, or', 'peepal-design' ); ?> <span class="drop__link"><?php esc_html_e( 'browse', 'peepal-design' ); ?></span></span>
                  <span class="drop__n"><?php esc_html_e( 'PDF or Word · up to 8 MB', 'peepal-design' ); ?></span>
                </label>
                <p class="drop__got" hidden>
                  <span class="drop__name" data-drop-name></span>
                  <button class="drop__x" type="button" data-drop-clear><?php esc_html_e( 'Remove', 'peepal-design' ); ?></button>
                </p>
              </div>
            </div>
            <label class="fld"><span class="fld__l"><?php esc_html_e( 'Anything you want us to read first?', 'peepal-design' ); ?></span>
              <textarea class="fld__i" name="note" rows="3" placeholder="<?php esc_attr_e( 'A project you are proud of, or why this role.', 'peepal-design' ); ?>"></textarea></label>
            <div class="fields__act">
              <button class="btn btn--mark" type="submit"><?php esc_html_e( 'Submit application', 'peepal-design' ); ?></button>
            </div>
            <p class="fields__msg" role="status" aria-live="polite"></p>
          </form>
        </aside>
      </div>
    </div>
  </div>
</div>

<!-- Hidden per-job templates, read by the modal script above on open. -->
<?php
if ( $peepal_jobs_query->have_posts() ) :
	while ( $peepal_jobs_query->have_posts() ) :
		$peepal_jobs_query->the_post();
		$peepal_job_terms = get_the_terms( get_the_ID(), 'job_function' );
		$peepal_job_fn    = ( is_array( $peepal_job_terms ) && $peepal_job_terms ) ? $peepal_job_terms[0]->name : '';
		?>
<template class="jd__src" data-fn="<?php echo esc_attr( $peepal_job_fn ); ?>" data-title="<?php the_title_attribute(); ?>" data-meta="<?php echo esc_attr( trim( get_post_meta( get_the_ID(), 'peepal_location', true ) . ' · ' . get_post_meta( get_the_ID(), 'peepal_experience', true ), ' ·' ) ); ?>"><?php echo apply_filters( 'the_content', get_the_content() ); // phpcs:ignore WordPress.Security.EscapeOutput -- already passed through the_content filter chain. ?></template>
		<?php
	endwhile;
	wp_reset_postdata();
endif;
	}
);

get_header();
?>

<article class="frame sec sec--case">
	<nav class="cs__crumb" aria-label="Breadcrumb">
		<a href="<?php echo esc_url( home_url( '/' ) ); ?>"><?php esc_html_e( 'Home', 'peepal-design' ); ?></a> <span aria-hidden="true">/</span>
		<span aria-current="page"><?php esc_html_e( 'Careers', 'peepal-design' ); ?></span>
	</nav>

	<header class="cs__head">
		<h1 class="cs__title develop"><?php the_title(); ?></h1>
		<?php if ( has_excerpt() ) : ?>
		<p class="cs__intro develop" data-delay="1"><?php echo esc_html( get_the_excerpt() ); ?></p>
		<?php endif; ?>
	</header>

	<?php
	get_template_part(
		'template-parts/hero-carousel',
		null,
		array(
			'images' => array( 'careers/hero-1.jpeg', 'careers/hero-2.jpeg', 'careers/hero-3.jpeg', 'careers/hero-4.jpeg' ),
			'label'  => __( 'Life at Peepal Design', 'peepal-design' ),
		)
	);
	?>

	<section class="cs develop" id="advantage">
		<header class="secthead" data-drift>
			<span class="secthead__over"><?php esc_html_e( 'Working here', 'peepal-design' ); ?></span>
			<h2 class="secthead__h"><?php esc_html_e( 'The Peepal advantage', 'peepal-design' ); ?></h2>
			<p class="secthead__p"><?php esc_html_e( 'Benefits and rituals that make work meaningful, sustainable and growth-focused.', 'peepal-design' ); ?></p>
		</header>
		<div class="svc">
			<div class="svc__col">
				<?php
				$peepal_advantages = array(
					array( 'title' => __( 'In-house workshops', 'peepal-design' ), 'body' => __( 'Skill development through expert sessions, hackdays and cross-discipline learning.', 'peepal-design' ) ),
					array( 'title' => __( 'Mentored internships', 'peepal-design' ), 'body' => __( 'Learn by shipping real work, with direct guidance from senior practitioners.', 'peepal-design' ) ),
					array( 'title' => __( 'Flexible work style', 'peepal-design' ), 'body' => __( 'Hybrid and remote-friendly collaboration, with trust, accountability and clear outcomes.', 'peepal-design' ) ),
					array( 'title' => __( 'Team rituals', 'peepal-design' ), 'body' => __( 'Friday insights, showcase sessions and collaborative critique loops.', 'peepal-design' ) ),
				);
				foreach ( $peepal_advantages as $peepal_index => $peepal_item ) :
					?>
				<article class="svc__item" data-svc="<?php echo esc_attr( $peepal_index ); ?>">
					<h3><?php echo esc_html( $peepal_item['title'] ); ?></h3>
					<p><?php echo esc_html( $peepal_item['body'] ); ?></p>
				</article>
				<?php endforeach; ?>
			</div>
			<div class="svc__stage" aria-hidden="true">
				<div class="svc__frame">
					<?php foreach ( $peepal_advantages as $peepal_index => $peepal_item ) : ?>
					<img class="svc__shot<?php echo 0 === $peepal_index ? ' is-on' : ''; ?>" src="<?php echo esc_url( $peepal_assets . '/img/careers/0' . ( $peepal_index + 1 ) . '.jpeg' ); ?>" alt="" width="896" height="1200" loading="lazy" decoding="async" data-svc="<?php echo esc_attr( $peepal_index ); ?>">
					<?php endforeach; ?>
					<span class="svc__stamp" id="svcStamp">01 &middot; <?php echo esc_html( $peepal_advantages[0]['title'] ); ?></span>
				</div>
			</div>
		</div>
	</section>

	<section class="cs develop" id="jobs">
		<header class="secthead" data-drift>
			<span class="secthead__over"><?php esc_html_e( 'Open roles', 'peepal-design' ); ?></span>
			<h2 class="secthead__h"><?php esc_html_e( 'Job openings', 'peepal-design' ); ?></h2>
			<p class="secthead__p"><?php esc_html_e( 'Find your opportunity to contribute and grow. Browse current roles by function.', 'peepal-design' ); ?></p>
		</header>
		<?php if ( $peepal_functions ) : ?>
		<div class="jobbar">
			<ul class="filters__row jobbar__filts" id="jobFilters"
					data-filters="jobList" data-filter-item=".job" data-filter-empty="jobsEmpty"
					data-page-size="4" data-pager="jobPager" data-filter-search="jobSearch">
				<li><button class="filt filt--chip is-on" type="button" data-cat="all" aria-pressed="true"><?php esc_html_e( 'All', 'peepal-design' ); ?></button></li>
				<?php foreach ( $peepal_functions as $peepal_term ) : ?>
				<li><button class="filt filt--chip" type="button" data-cat="<?php echo esc_attr( $peepal_term->slug ); ?>" aria-pressed="false"><?php echo esc_html( $peepal_term->name ); ?></button></li>
				<?php endforeach; ?>
			</ul>
			<div class="jobsearch">
				<label class="vh" for="jobSearch"><?php esc_html_e( 'Search roles', 'peepal-design' ); ?></label>
				<svg class="jobsearch__ico" viewBox="0 0 16 16" aria-hidden="true"><circle cx="7" cy="7" r="5" fill="none" stroke="currentColor" stroke-width="1.5"/><path d="m11 11 4 4" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"/></svg>
				<input class="jobsearch__in" id="jobSearch" type="search" placeholder="<?php esc_attr_e( 'Search roles', 'peepal-design' ); ?>" autocomplete="off">
			</div>
		</div>
		<?php endif; ?>
		<div class="jobs" id="jobList">
			<?php
			if ( $peepal_jobs_query->have_posts() ) :
				while ( $peepal_jobs_query->have_posts() ) :
					$peepal_jobs_query->the_post();
					$peepal_job_terms = get_the_terms( get_the_ID(), 'job_function' );
					$peepal_job_slugs = is_array( $peepal_job_terms ) ? wp_list_pluck( $peepal_job_terms, 'slug' ) : array();
					$peepal_location  = get_post_meta( get_the_ID(), 'peepal_location', true );
					$peepal_experience = get_post_meta( get_the_ID(), 'peepal_experience', true );
					?>
			<article class="job" data-cats="<?php echo esc_attr( implode( ' ', $peepal_job_slugs ) ); ?>">
				<div class="job__body">
					<h3 class="job__t"><?php the_title(); ?></h3>
					<?php if ( has_excerpt() ) : ?>
					<p class="job__p"><?php echo esc_html( get_the_excerpt() ); ?></p>
					<?php endif; ?>
					<?php if ( $peepal_location || $peepal_experience ) : ?>
					<p class="job__meta"><?php echo esc_html( $peepal_location ); ?> <span aria-hidden="true">·</span> <?php echo esc_html( $peepal_experience ); ?></p>
					<?php endif; ?>
				</div>
				<a class="btn btn--ghost job__cta" href="<?php echo esc_url( home_url( '/#contact' ) ); ?>" data-sheet-open="job"><?php esc_html_e( 'Apply now', 'peepal-design' ); ?></a>
			</article>
					<?php
				endwhile;
				wp_reset_postdata();
			endif;
			?>
		</div>
		<p class="jobs__empty" id="jobsEmpty" hidden><?php esc_html_e( 'No open roles matching', 'peepal-design' ); ?> <span data-empty-term><?php esc_html_e( 'this function', 'peepal-design' ); ?></span> <?php esc_html_e( 'right now.', 'peepal-design' ); ?> <a href="<?php echo esc_url( home_url( '/#contact' ) ); ?>"><?php esc_html_e( 'Send us your work anyway', 'peepal-design' ); ?></a> <?php esc_html_e( '— we keep good people in mind.', 'peepal-design' ); ?></p>
	</section>

	<section class="cs develop" id="process">
		<header class="secthead" data-drift>
			<span class="secthead__over"><?php esc_html_e( 'How we hire', 'peepal-design' ); ?></span>
			<h2 class="secthead__h"><?php esc_html_e( 'The application process', 'peepal-design' ); ?></h2>
			<p class="secthead__p"><?php esc_html_e( 'Designed to be transparent and candidate-friendly. Not just an evaluation — a two-way conversation.', 'peepal-design' ); ?></p>
		</header>
		<div class="vtabs" data-vtabs>
			<div class="vtabs__list" role="tablist" aria-label="<?php esc_attr_e( 'Stages of the application process', 'peepal-design' ); ?>" aria-orientation="vertical">
				<?php
				$peepal_steps = array(
					array( 'title' => __( 'Getting to know you', 'peepal-design' ) ),
					array( 'title' => __( 'Take-home task', 'peepal-design' ) ),
					array( 'title' => __( 'A chat', 'peepal-design' ) ),
					array( 'title' => __( 'Valuable feedback', 'peepal-design' ) ),
				);
				foreach ( $peepal_steps as $peepal_index => $peepal_step ) :
					$peepal_num = sprintf( '%02d', $peepal_index + 1 );
					?>
				<button class="vtab<?php echo 0 === $peepal_index ? ' is-on' : ''; ?>" type="button" role="tab"
						id="vt-<?php echo esc_attr( $peepal_num ); ?>" aria-controls="vp-<?php echo esc_attr( $peepal_num ); ?>" aria-selected="<?php echo 0 === $peepal_index ? 'true' : 'false'; ?>" tabindex="<?php echo 0 === $peepal_index ? '0' : '-1'; ?>">
					<span class="vtab__t"><?php echo esc_html( $peepal_step['title'] ); ?></span>
				</button>
				<?php endforeach; ?>
			</div>
			<div class="vtabs__panels">
				<?php
				$peepal_step_bodies = array(
					array(
						__( 'We start with your story, skills and ambitions. This first step helps us understand what motivates you, and where your strengths can create the most impact.', 'peepal-design' ),
						__( 'No task, no whiteboard. A conversation about the work you have done, the work you want to do next, and whether the two point in the same direction as the roles we have open.', 'peepal-design' ),
					),
					array(
						__( 'A short, realistic problem drawn from the kind of work we actually do. Not a trick question, and not a free deliverable for a live client project.', 'peepal-design' ),
						__( 'We tell you upfront roughly how long it should take, and you fit it around your week rather than a countdown. What we read is how you frame the problem and what you chose to leave out — not only the artefact at the end.', 'peepal-design' ),
					),
					array(
						__( 'A conversation with the people you would actually sit beside, not a panel you have never met.', 'peepal-design' ),
						__( 'We walk through your task together and talk about how you think when the brief is unclear. Half the time belongs to your questions — about the team, the projects, or anything you need in order to decide about us.', 'peepal-design' ),
					),
					array(
						__( 'Whatever the outcome, you hear back with something you can use.', 'peepal-design' ),
						__( 'We tell you what stood out, where we saw gaps, and how we reached the decision. Interviewing takes real effort, and being left without a straight answer is the part of hiring candidates tell us they find hardest.', 'peepal-design' ),
					),
				);
				foreach ( $peepal_steps as $peepal_index => $peepal_step ) :
					$peepal_num = sprintf( '%02d', $peepal_index + 1 );
					?>
				<div class="vpanel" role="tabpanel" id="vp-<?php echo esc_attr( $peepal_num ); ?>" aria-labelledby="vt-<?php echo esc_attr( $peepal_num ); ?>"<?php echo 0 === $peepal_index ? '' : ' hidden'; ?>>
					<span class="vpanel__k"><?php echo esc_html( sprintf( __( 'Step %s', 'peepal-design' ), $peepal_num ) ); ?></span>
					<h3 class="vpanel__h"><?php echo esc_html( $peepal_step['title'] ); ?></h3>
					<?php foreach ( $peepal_step_bodies[ $peepal_index ] as $peepal_paragraph ) : ?>
					<p class="vpanel__p"><?php echo esc_html( $peepal_paragraph ); ?></p>
					<?php endforeach; ?>
				</div>
				<?php endforeach; ?>
			</div>
		</div>
	</section>
</article>

<section class="frame sec sec--pitch">
	<div class="pitch">
		<h2 class="pitch__h develop"><?php esc_html_e( 'Stay ahead with career updates', 'peepal-design' ); ?></h2>
		<p class="pitch__p develop" data-delay="1"><?php esc_html_e( 'Get updates on new openings, team stories and learning opportunities from Peepal Design.', 'peepal-design' ); ?></p>
		<form class="signup develop" data-signup data-delay="2" action="<?php echo esc_url( home_url( '/#contact' ) ); ?>" method="get" novalidate>
			<label class="vh" for="signupEmail"><?php esc_html_e( 'Email address', 'peepal-design' ); ?></label>
			<input class="signup__in" id="signupEmail" name="email" type="email"
			       placeholder="<?php esc_attr_e( 'Email address', 'peepal-design' ); ?>" autocomplete="email" required
			       aria-describedby="signupMsg">
			<button class="btn btn--mark signup__go" type="submit"><?php esc_html_e( 'Subscribe', 'peepal-design' ); ?></button>
			<p class="signup__msg" id="signupMsg" role="status" aria-live="polite"></p>
		</form>
	</div>
</section>

<?php get_footer(); ?>
