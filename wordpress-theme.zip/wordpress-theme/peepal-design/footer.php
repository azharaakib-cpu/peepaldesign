<?php
/**
 * Closes <main> (opened in header.php), then the site footer, back-to-top
 * control, and wp_footer(). Ported near-verbatim from the static site —
 * every page carried a byte-identical copy except for the internal-anchor
 * URL scheme, which home_url() now resolves the same way on every page
 * (the static site needed an "index.html#" prefix on non-home pages only;
 * that distinction disappears once every anchor is home_url('/#...')).
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$peepal_assets = PEEPAL_THEME_URI . '/assets';
?>
</main>

<footer class="foot">
  <div class="foot__grid">
    <div class="foot__brand">
      <a class="logo logo--foot" href="<?php echo esc_url( home_url( '/' ) ); ?>" aria-label="<?php esc_attr_e( 'Peepal Design home', 'peepal-design' ); ?>">
        <img class="logo__mark" src="<?php echo esc_url( $peepal_assets . '/brand/logomark.svg' ); ?>" alt="" width="24" height="24"
             onerror="this.onerror=null;this.src='<?php echo esc_url( $peepal_assets . '/brand/logomark.png' ); ?>'">
        <span class="logo__word">peepaldesign</span>
      </a>
      <p>A research-first UX studio. Part of Bridged Global — a worldwide network of UX designers and design specialists. Founded 2016. Mumbai, India.</p>
      <div class="foot__social">
        <a href="#top" aria-label="LinkedIn"><svg viewBox="0 0 20 20" aria-hidden="true"><path d="M4.5 7.5h2.6V16H4.5zM5.8 3.4a1.6 1.6 0 1 1 0 3.2 1.6 1.6 0 0 1 0-3.2ZM9.3 7.5h2.5v1.2a2.8 2.8 0 0 1 2.5-1.4c2 0 3.2 1.3 3.2 3.7V16h-2.6v-4.4c0-1.2-.4-1.9-1.4-1.9-1 0-1.6.7-1.6 1.9V16H9.3Z" fill="currentColor"/></svg></a>
        <a href="#top" aria-label="X"><svg viewBox="0 0 20 20" aria-hidden="true"><path d="M4 4h3.2l3.1 4.3L13.9 4H16l-4.6 5.6L16.4 16h-3.2l-3.4-4.6L5.9 16H4l4.9-6L4 4Z" fill="currentColor"/></svg></a>
        <a href="#top" aria-label="Instagram"><svg viewBox="0 0 20 20" aria-hidden="true"><rect x="3.5" y="3.5" width="13" height="13" rx="4" fill="none" stroke="currentColor" stroke-width="1.4"/><circle cx="10" cy="10" r="3.2" fill="none" stroke="currentColor" stroke-width="1.4"/><circle cx="14" cy="6" r="1" fill="currentColor"/></svg></a>
        <a href="#top" aria-label="Behance"><svg viewBox="0 0 20 20" aria-hidden="true"><path d="M2 5h4.6c1.8 0 2.9.8 2.9 2.2 0 1-.5 1.6-1.3 1.9 1 .3 1.7 1 1.7 2.2 0 1.7-1.3 2.7-3.3 2.7H2Zm2 3.4h2.2c.7 0 1.2-.3 1.2-.9s-.4-.9-1.2-.9H4Zm0 4h2.4c.9 0 1.4-.4 1.4-1s-.5-1-1.4-1H4ZM12 5.6h4.6V7H12ZM14.4 8.2c2 0 3.3 1.4 3.3 3.5v.5h-4.8c.1.9.7 1.4 1.6 1.4.7 0 1.1-.2 1.4-.7h1.7c-.4 1.4-1.6 2.2-3.1 2.2-2 0-3.4-1.4-3.4-3.4s1.4-3.5 3.3-3.5Zm-1.5 2.8h3c-.1-.8-.7-1.3-1.5-1.3s-1.4.5-1.5 1.3Z" fill="currentColor"/></svg></a>
      </div>
    </div>

    <nav class="foot__col" aria-label="Services">
      <span class="foot__code">SERVICES</span>
      <a href="<?php echo esc_url( home_url( '/#services' ) ); ?>">User Research</a>
      <a href="<?php echo esc_url( home_url( '/#services' ) ); ?>">UX Design</a>
      <a href="<?php echo esc_url( home_url( '/#services' ) ); ?>">LEGO® Serious Play</a>
      <a href="<?php echo esc_url( home_url( '/#services' ) ); ?>">UX Training</a>
      <a href="<?php echo esc_url( home_url( '/#services' ) ); ?>">UX Audit</a>
    </nav>

    <nav class="foot__col" aria-label="Company">
      <span class="foot__code">COMPANY</span>
      <a href="<?php echo esc_url( home_url( '/#global' ) ); ?>">About Us</a>
      <a href="<?php echo esc_url( home_url( '/#services' ) ); ?>">Services</a>
      <a href="<?php echo esc_url( home_url( '/portfolio/' ) ); ?>">Work</a>
      <a href="<?php echo esc_url( home_url( '/#services' ) ); ?>">Training</a>
      <a href="<?php echo esc_url( home_url( '/blog/' ) ); ?>">Insights &amp; Blog</a>
      <a href="<?php echo esc_url( home_url( '/careers/' ) ); ?>"<?php peepal_nav_aria_current( '/careers/' ); ?>>Careers</a>
      <a href="<?php echo esc_url( home_url( '/#contact' ) ); ?>">Contact Us</a>
    </nav>

    <nav class="foot__col" aria-label="Global family">
      <span class="foot__code">GLOBAL FAMILY</span>
      <a href="https://boldinsight.com/" target="_blank" rel="noopener">Bold Insight</a>
      <a href="https://www.uintent.com/" target="_blank" rel="noopener">uintent</a>
      <a href="https://uism.co.jp/" target="_blank" rel="noopener">UIsm</a>
      <a href="https://www.xplusx.net/" target="_blank" rel="noopener">XPLUSX</a>
    </nav>
  </div>

  <div class="foot__bar">
    <span>© <?php echo esc_html( gmdate( 'Y' ) ); ?> Peepal Design — User Experience Design Consulting Pvt. Ltd.</span>
    <span class="foot__legal"><a href="<?php echo esc_url( home_url( '/#top' ) ); ?>">Privacy Policy</a><a href="<?php echo esc_url( home_url( '/#top' ) ); ?>">Terms of Use</a></span>
  </div>
</footer>

<!-- A real anchor, so the page still returns to the top with JavaScript off;
     the script only decides when the plate is visible. -->
<a class="totop" id="toTop" href="#top" aria-label="Back to top">
  <svg class="totop__glyph" viewBox="0 0 14 14" fill="none" stroke="currentColor"
       stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">
    <path d="M2.4 2.4h9.2"/>
    <g class="totop__arrow"><path d="M7 12.6V5.6"/><path d="M3.6 9 7 5.6 10.4 9"/></g>
  </svg>
  <span class="totop__code" aria-hidden="true">Top</span>
</a>

<?php wp_footer(); ?>
</body>
</html>
