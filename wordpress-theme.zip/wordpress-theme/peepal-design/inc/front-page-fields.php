<?php
/**
 * The handful of homepage fields front-page.php reads (hero sub-copy, the
 * 4 stat-counter value/suffix/label triples). Registered directly here
 * rather than through peepal_register_meta_box() because this metabox
 * must appear ONLY on whichever Page is set as the static front page
 * (Settings -> Reading), not on every Page — the generic helper doesn't
 * have a concept of "one specific post," so it's simpler to write this
 * one by hand than to bend that helper to a single special case.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

function peepal_is_front_page_screen( int $post_id ): bool {
	$front_id = (int) get_option( 'page_on_front' );

	return $front_id > 0 && $front_id === $post_id;
}

add_action(
	'add_meta_boxes_page',
	function () {
		global $post;
		if ( ! $post || ! peepal_is_front_page_screen( $post->ID ) ) {
			return;
		}
		add_meta_box(
			'peepal_front_page_fields',
			__( 'Homepage hero & stats', 'peepal-design' ),
			'peepal_render_front_page_fields',
			'page',
			'normal',
			'high'
		);
	}
);

function peepal_render_front_page_fields( WP_Post $post ): void {
	wp_nonce_field( 'peepal_save_front_page_fields', 'peepal_front_page_fields_nonce' );

	$sub = get_post_meta( $post->ID, 'peepal_hero_sub', true );
	echo '<p><label for="peepal_hero_sub"><strong>' . esc_html__( 'Hero sub-copy', 'peepal-design' ) . '</strong></label><br>';
	echo '<textarea id="peepal_hero_sub" name="peepal_hero_sub" rows="2" style="width:100%;">' . esc_textarea( $sub ) . '</textarea>';
	echo '<br><span class="description">' . esc_html__( 'The paragraph under the H1. The headline itself is fixed, client-approved copy with specific word colouring baked into the markup, so it is not editable here.', 'peepal-design' ) . '</span></p>';

	echo '<p><strong>' . esc_html__( 'Stat counters', 'peepal-design' ) . '</strong></p>';
	for ( $i = 1; $i <= 4; $i++ ) {
		$value  = get_post_meta( $post->ID, "peepal_stat_{$i}_value", true );
		$suffix = get_post_meta( $post->ID, "peepal_stat_{$i}_suffix", true );
		$label  = get_post_meta( $post->ID, "peepal_stat_{$i}_label", true );
		echo '<p style="display:flex;gap:8px;align-items:flex-end;">';
		echo '<span><label for="peepal_stat_' . esc_attr( $i ) . '_value">' . esc_html__( 'Value', 'peepal-design' ) . '</label><br><input type="text" id="peepal_stat_' . esc_attr( $i ) . '_value" name="peepal_stat_' . esc_attr( $i ) . '_value" value="' . esc_attr( $value ) . '" style="width:90px;"></span>';
		echo '<span><label for="peepal_stat_' . esc_attr( $i ) . '_suffix">' . esc_html__( 'Suffix', 'peepal-design' ) . '</label><br><input type="text" id="peepal_stat_' . esc_attr( $i ) . '_suffix" name="peepal_stat_' . esc_attr( $i ) . '_suffix" value="' . esc_attr( $suffix ) . '" style="width:50px;"></span>';
		echo '<span style="flex:1;"><label for="peepal_stat_' . esc_attr( $i ) . '_label">' . esc_html__( 'Label', 'peepal-design' ) . '</label><br><input type="text" id="peepal_stat_' . esc_attr( $i ) . '_label" name="peepal_stat_' . esc_attr( $i ) . '_label" value="' . esc_attr( $label ) . '" style="width:100%;"></span>';
		echo '</p>';
	}
}

add_action(
	'save_post_page',
	function ( int $post_id ) {
		if ( ! peepal_is_front_page_screen( $post_id ) ) {
			return;
		}
		if ( ! isset( $_POST['peepal_front_page_fields_nonce'] ) || ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['peepal_front_page_fields_nonce'] ) ), 'peepal_save_front_page_fields' ) ) {
			return;
		}
		if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) {
			return;
		}
		if ( ! current_user_can( 'edit_post', $post_id ) ) {
			return;
		}

		if ( isset( $_POST['peepal_hero_sub'] ) ) {
			update_post_meta( $post_id, 'peepal_hero_sub', sanitize_textarea_field( wp_unslash( $_POST['peepal_hero_sub'] ) ) );
		}

		for ( $i = 1; $i <= 4; $i++ ) {
			foreach ( array( 'value', 'suffix', 'label' ) as $field ) {
				$key = "peepal_stat_{$i}_{$field}";
				if ( isset( $_POST[ $key ] ) ) {
					update_post_meta( $post_id, $key, sanitize_text_field( wp_unslash( $_POST[ $key ] ) ) );
				}
			}
		}
	}
);
