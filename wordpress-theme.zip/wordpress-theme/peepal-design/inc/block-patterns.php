<?php
/**
 * Block Patterns are how this theme gets "flexible content" without ACF
 * or a custom repeater UI (see the plan's architecture note for the full
 * reasoning). Each pattern is a single core/html block carrying exactly
 * the static site's markup for that section type, with placeholder copy
 * an editor overwrites. Using core/html rather than nested Group/Heading
 * blocks means WordPress never runs its block-validation against this
 * markup — a typo can't produce an "unexpected or invalid content" error
 * in the editor, which matters a lot given nothing here has been tested
 * against a live block editor.
 *
 * IMPORTANT for content editors: every pattern below carries an `id="..."`
 * on its outer <section> or <div class="definitionsec"> wrapper. Section
 * navigation (FAQ anchors, the case-study tab bar built by
 * peepal_build_csnav() in inc/template-tags.php) reads those ids directly
 * out of the rendered content — keep each one unique on a given page, and
 * update it if you rewrite a section's heading.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

function peepal_register_block_pattern_category(): void {
	register_block_pattern_category(
		'peepal-sections',
		array( 'label' => __( 'Peepal Design sections', 'peepal-design' ) )
	);
}
add_action( 'init', 'peepal_register_block_pattern_category' );

function peepal_wrap_html_block( string $markup ): string {
	return "<!-- wp:html -->\n" . $markup . "\n<!-- /wp:html -->";
}

function peepal_register_block_patterns(): void {

	register_block_pattern(
		'peepal/section-definition',
		array(
			'title'      => __( 'Service section: Definition grid', 'peepal-design' ),
			'description' => __( 'Sticky header + a grid of short definition cards (.lvls.lvls--1up). Duplicate or delete an .lvl article to change the count.', 'peepal-design' ),
			'categories' => array( 'peepal-sections' ),
			'content'    => peepal_wrap_html_block(
				'<section class="cs" id="definition">
  <div class="definitionsec">
    <header class="secthead" data-drift>
      <h2 class="secthead__h">Section headline</h2>
      <p class="secthead__p">One sentence framing what this grid is showing.</p>
    </header>
    <div class="lvls lvls--1up">
      <article class="lvl">
        <h3 class="lvl__title">First term</h3>
        <p class="lvl__body">What it means, in plain language.</p>
      </article>
      <article class="lvl">
        <h3 class="lvl__title">Second term</h3>
        <p class="lvl__body">What it means, in plain language.</p>
      </article>
      <article class="lvl">
        <h3 class="lvl__title">Third term</h3>
        <p class="lvl__body">What it means, in plain language.</p>
      </article>
      <article class="lvl">
        <h3 class="lvl__title">Fourth term</h3>
        <p class="lvl__body">What it means, in plain language.</p>
      </article>
    </div>
  </div>
</section>'
			),
		)
	);

	register_block_pattern(
		'peepal/section-why',
		array(
			'title'      => __( 'Service section: Why it matters (paragraphs)', 'peepal-design' ),
			'description' => __( 'Sticky header + a stack of bold-led persuasion paragraphs (.plead-stack). Duplicate or delete a .plead paragraph to change the count.', 'peepal-design' ),
			'categories' => array( 'peepal-sections' ),
			'content'    => peepal_wrap_html_block(
				'<section class="cs" id="why">
  <div class="definitionsec">
    <header class="secthead" data-drift>
      <h2 class="secthead__h">Why this matters</h2>
      <p class="secthead__p">One sentence setting up the case you are about to make.</p>
    </header>
    <div class="plead-stack">
      <p class="plead"><strong>Short bold lead-in.</strong> One or two sentences expanding on it.</p>
      <p class="plead"><strong>Short bold lead-in.</strong> One or two sentences expanding on it.</p>
      <p class="plead"><strong>Short bold lead-in.</strong> One or two sentences expanding on it.</p>
      <p class="plead"><strong>Short bold lead-in.</strong> One or two sentences expanding on it.</p>
    </div>
  </div>
</section>'
			),
		)
	);

	register_block_pattern(
		'peepal/section-principles',
		array(
			'title'      => __( 'Service section: Numbered principle cards', 'peepal-design' ),
			'description' => __( 'Sticky header + numbered cards (.qcards). Duplicate or delete a .qcard article to change the count, and renumber .qcard__no.', 'peepal-design' ),
			'categories' => array( 'peepal-sections' ),
			'content'    => peepal_wrap_html_block(
				'<section class="cs" id="principles">
  <div class="definitionsec">
    <header class="secthead" data-drift>
      <h2 class="secthead__h">What stays the same</h2>
      <p class="secthead__p">One sentence framing the principles below.</p>
    </header>
    <div class="qcards">
      <article class="qcard">
        <span class="qcard__no">01</span>
        <h3 class="qcard__t">First principle</h3>
        <p class="qcard__d">A sentence or two explaining it.</p>
      </article>
      <article class="qcard">
        <span class="qcard__no">02</span>
        <h3 class="qcard__t">Second principle</h3>
        <p class="qcard__d">A sentence or two explaining it.</p>
      </article>
      <article class="qcard">
        <span class="qcard__no">03</span>
        <h3 class="qcard__t">Third principle</h3>
        <p class="qcard__d">A sentence or two explaining it.</p>
      </article>
    </div>
  </div>
</section>'
			),
		)
	);

	register_block_pattern(
		'peepal/section-faq',
		array(
			'title'      => __( 'FAQ section', 'peepal-design' ),
			'description' => __( 'Sticky header + a 2-column accordion (.lightbox / .qa). The accordion open/close behaviour comes from main.js reading these exact classes — do not rename qa__q/qa__a.', 'peepal-design' ),
			'categories' => array( 'peepal-sections' ),
			'content'    => peepal_wrap_html_block(
				'<section class="cs" id="faq">
  <div class="definitionsec">
    <header class="secthead" data-drift>
      <h2 class="secthead__h">Frequently asked questions</h2>
    </header>
    <div class="lightbox">
      <div class="lightbox__col">
        <div class="qa"><button class="qa__q" aria-expanded="false"><span>First question?</span><svg class="qa__x" viewBox="0 0 16 16" aria-hidden="true"><path d="M8 2v12M2 8h12" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round"/></svg></button><div class="qa__a"><div><p>Answer.</p></div></div></div>
        <div class="qa"><button class="qa__q" aria-expanded="false"><span>Second question?</span><svg class="qa__x" viewBox="0 0 16 16" aria-hidden="true"><path d="M8 2v12M2 8h12" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round"/></svg></button><div class="qa__a"><div><p>Answer.</p></div></div></div>
      </div>
      <div class="lightbox__col">
        <div class="qa"><button class="qa__q" aria-expanded="false"><span>Third question?</span><svg class="qa__x" viewBox="0 0 16 16" aria-hidden="true"><path d="M8 2v12M2 8h12" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round"/></svg></button><div class="qa__a"><div><p>Answer.</p></div></div></div>
        <div class="qa"><button class="qa__q" aria-expanded="false"><span>Fourth question?</span><svg class="qa__x" viewBox="0 0 16 16" aria-hidden="true"><path d="M8 2v12M2 8h12" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round"/></svg></button><div class="qa__a"><div><p>Answer.</p></div></div></div>
      </div>
    </div>
  </div>
</section>'
			),
		)
	);

	register_block_pattern(
		'peepal/section-header-only',
		array(
			'title'      => __( 'Section: heading only', 'peepal-design' ),
			'description' => __( 'A plain overline + heading + lede paragraph, no body grid underneath (.secthead on its own) — used for short narrative statements like Our Journey\'s About/Values sections.', 'peepal-design' ),
			'categories' => array( 'peepal-sections' ),
			'content'    => peepal_wrap_html_block(
				'<section class="cs" id="section-name">
  <header class="secthead">
    <span class="secthead__over">Overline</span>
    <h2 class="secthead__h">Section headline</h2>
    <p class="secthead__p">Supporting sentence.</p>
  </header>
</section>'
			),
		)
	);

	register_block_pattern(
		'peepal/section-header-body',
		array(
			'title'      => __( 'Section: heading + body paragraph', 'peepal-design' ),
			'description' => __( 'A .secthead followed by a .cs__body paragraph — for a short narrative section that needs one supporting paragraph but no grid (Our Global Family\'s "The network" / "Reach" sections).', 'peepal-design' ),
			'categories' => array( 'peepal-sections' ),
			'content'    => peepal_wrap_html_block(
				'<section class="cs" id="section-name">
  <header class="secthead">
    <span class="secthead__over">Overline</span>
    <h2 class="secthead__h">Section headline</h2>
    <p class="secthead__p">Supporting sentence.</p>
  </header>
  <div class="cs__body">
    <p>Body paragraph.</p>
  </div>
</section>'
			),
		)
	);

	register_block_pattern(
		'peepal/case-text-section',
		array(
			'title'      => __( 'Case study section: Text', 'peepal-design' ),
			'description' => __( 'A simple labelled section (.cs__label + .cs__body). Give it a unique id — the case-study tab bar is built from these ids.', 'peepal-design' ),
			'categories' => array( 'peepal-sections' ),
			'content'    => peepal_wrap_html_block(
				'<section class="cs" id="brief">
  <h2 class="cs__label">Section name</h2>
  <div class="cs__body">
    <p>First paragraph.</p>
    <p>Second paragraph.</p>
  </div>
</section>'
			),
		)
	);

	register_block_pattern(
		'peepal/case-text-section-image',
		array(
			'title'      => __( 'Case study section: Text + image', 'peepal-design' ),
			'description' => __( 'Same as the plain text section, with a supporting image plate underneath. Replace IMAGE-URL-HERE with a Media Library file URL.', 'peepal-design' ),
			'categories' => array( 'peepal-sections' ),
			'content'    => peepal_wrap_html_block(
				'<section class="cs" id="challenge">
  <h2 class="cs__label">Section name</h2>
  <div class="cs__body">
    <p>First paragraph.</p>
    <p>Second paragraph.</p>
  </div>
  <figure class="cs__plate">
    <img src="IMAGE-URL-HERE" alt="Describe the image for screen readers" loading="lazy" decoding="async">
  </figure>
</section>'
			),
		)
	);

	register_block_pattern(
		'peepal/case-two-column-section',
		array(
			'title'      => __( 'Case study section: Two columns', 'peepal-design' ),
			'description' => __( 'A method/findings-style split — two eyebrow+sub-heading+paragraph blocks side by side.', 'peepal-design' ),
			'categories' => array( 'peepal-sections' ),
			'content'    => peepal_wrap_html_block(
				'<section class="cs" id="discover">
  <h2 class="cs__label">Section name</h2>
  <div class="cs__body">
    <div>
      <span class="cs__eyebrow">First column label</span>
      <h2 class="cs__sub">Sub-heading</h2>
      <p>Paragraph.</p>
    </div>
    <div>
      <span class="cs__eyebrow">Second column label</span>
      <h2 class="cs__sub">Sub-heading</h2>
      <p>Paragraph.</p>
    </div>
  </div>
</section>'
			),
		)
	);

	register_block_pattern(
		'peepal/case-persona-grid',
		array(
			'title'      => __( 'Case study section: Persona grid', 'peepal-design' ),
			'description' => __( 'A row of persona cards (.pcards / .pcard) — quote, meta line, name, Goals and Opportunities lists. Duplicate or delete a .pcard article to change the count.', 'peepal-design' ),
			'categories' => array( 'peepal-sections' ),
			'content'    => peepal_wrap_html_block(
				'<section class="cs" id="personas">
  <h2 class="cs__label">Personas</h2>
  <div class="cs__body">
    <p>One sentence introducing the personas below.</p>
  </div>
  <div class="pcards">
    <article class="pcard">
      <blockquote class="pcard__quote">&ldquo;A representative quote.&rdquo;</blockquote>
      <p class="pcard__meta">Age &middot; Gender &middot; City &middot; Role</p>
      <h3 class="pcard__name">Persona name</h3>
      <div class="pcard__lists">
        <div>
          <span class="pcard__lab">Goals</span>
          <ul class="pcard__list">
            <li>Goal one</li>
            <li>Goal two</li>
          </ul>
        </div>
        <div>
          <span class="pcard__lab">Opportunities</span>
          <ul class="pcard__list">
            <li>Opportunity one</li>
            <li>Opportunity two</li>
          </ul>
        </div>
      </div>
    </article>
  </div>
</section>'
			),
		)
	);
	register_block_pattern(
		'peepal/job-description',
		array(
			'title'      => __( 'Job opening: full description', 'peepal-design' ),
			'description' => __( 'The lead paragraph plus the three labelled lists (What you\'ll do / What you\'ll bring / Nice to have) shown in the job detail modal. Duplicate or delete an <li> to change list length; keep all three .jd__block groups.', 'peepal-design' ),
			'categories' => array( 'peepal-sections' ),
			'content'    => peepal_wrap_html_block(
				'<p class="jd__lead">One or two sentences on what this role actually does day to day.</p>
<div class="jd__block"><h4 class="jd__h">What you\'ll do</h4><ul class="jd__list">
<li>Responsibility one.</li>
<li>Responsibility two.</li>
</ul></div>
<div class="jd__block"><h4 class="jd__h">What you\'ll bring</h4><ul class="jd__list">
<li>Requirement one.</li>
<li>Requirement two.</li>
</ul></div>
<div class="jd__block"><h4 class="jd__h">Nice to have</h4><ul class="jd__list">
<li>Bonus one.</li>
<li>Bonus two.</li>
</ul></div>'
			),
		)
	);
	register_block_pattern(
		'peepal/crew-grid',
		array(
			'title'      => __( 'Team / trainer photo grid', 'peepal-design' ),
			'description' => __( 'A row of portrait cards (.crew / .crew__m) — used for "meet the leaders" on Our Journey and trainer lineups on Training pages. Each course curates its own lineup, which is why this is a content pattern rather than a shared CPT query. Duplicate or delete a .crew__m figure to change the count.', 'peepal-design' ),
			'categories' => array( 'peepal-sections' ),
			'content'    => peepal_wrap_html_block(
				'<div class="crew">
  <figure class="crew__m">
    <div class="crew__shot">
      <img class="crew__img" src="IMAGE-URL-HERE" alt="Full name" width="624" height="624" loading="lazy" decoding="async" onerror="this.remove()">
      <span class="crew__mono" aria-hidden="true">XX</span>
    </div>
    <figcaption class="crew__cap">
      <span class="crew__name">Full name</span>
      <span class="crew__role">Role or title</span>
    </figcaption>
  </figure>
</div>'
			),
		)
	);
}
add_action( 'init', 'peepal_register_block_patterns' );
