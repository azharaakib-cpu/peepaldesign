<?php
/**
 * Network offices/partners shown on Our Global Family's "cities" grid.
 * A real CPT (not a Block Pattern) because these are genuinely
 * add/remove/reorder-able list items with the same field shape every
 * time — a WP_Query loop with native menu_order drag-reordering suits
 * this better than hand-edited HTML.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

function peepal_register_cpt_office(): void {
	register_post_type(
		'office',
		array(
			'labels'       => array(
				'name'          => __( 'Offices', 'peepal-design' ),
				'singular_name' => __( 'Office', 'peepal-design' ),
				'add_new_item'  => __( 'Add New Office', 'peepal-design' ),
				'edit_item'     => __( 'Edit Office', 'peepal-design' ),
				'all_items'     => __( 'Offices', 'peepal-design' ),
			),
			'public'       => false,
			'publicly_queryable' => false,
			'show_ui'      => true,
			'show_in_menu' => true,
			'show_in_rest' => true,
			'menu_icon'    => 'dashicons-admin-site-alt3',
			'supports'     => array( 'title', 'editor', 'thumbnail', 'page-attributes' ),
		)
	);
}
add_action( 'init', 'peepal_register_cpt_office' );

peepal_register_meta_box(
	'office',
	'peepal_office_details',
	__( 'Office details', 'peepal-design' ),
	array(
		'peepal_link' => array(
			'label'       => __( 'Website link', 'peepal-design' ),
			'type'        => 'text',
			'description' => __( 'Where "Visit website" points. Featured image is the partner logo (matches .lvl__logo); Title is the city name; the editor content is the one-sentence description.', 'peepal-design' ),
		),
	)
);
