<?php
/**
 * Homepage testimonial reel. Real CPT: same field shape every time,
 * looped via WP_Query, ordered by menu_order (drag-and-drop under Page
 * Attributes).
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

function peepal_register_cpt_testimonial(): void {
	register_post_type(
		'testimonial',
		array(
			'labels'             => array(
				'name'          => __( 'Testimonials', 'peepal-design' ),
				'singular_name' => __( 'Testimonial', 'peepal-design' ),
				'add_new_item'  => __( 'Add New Testimonial', 'peepal-design' ),
				'edit_item'     => __( 'Edit Testimonial', 'peepal-design' ),
				'all_items'     => __( 'Testimonials', 'peepal-design' ),
			),
			'public'             => false,
			'publicly_queryable' => false,
			'show_ui'            => true,
			'show_in_menu'       => true,
			'show_in_rest'       => true,
			'menu_icon'          => 'dashicons-format-quote',
			'supports'           => array( 'title', 'editor', 'thumbnail', 'page-attributes' ),
		)
	);
}
add_action( 'init', 'peepal_register_cpt_testimonial' );

peepal_register_meta_box(
	'testimonial',
	'peepal_testimonial_details',
	__( 'Testimonial details', 'peepal-design' ),
	array(
		'peepal_author_name' => array(
			'label' => __( 'Name', 'peepal-design' ),
			'type'  => 'text',
		),
		'peepal_author_role' => array(
			'label'       => __( 'Role / organisation', 'peepal-design' ),
			'type'        => 'text',
			'description' => __( 'Title is unused for display — the quote itself is the editor content, and the featured image is the organisation logo.', 'peepal-design' ),
		),
		'peepal_org_name'    => array(
			'label'       => __( 'Organisation name', 'peepal-design' ),
			'type'        => 'text',
			'description' => __( 'Alt text for the organisation logo image.', 'peepal-design' ),
		),
		'peepal_rating'      => array(
			'label'       => __( 'Star rating', 'peepal-design' ),
			'type'        => 'text',
			'description' => __( 'A number 1–5. Leave blank to show no stars.', 'peepal-design' ),
		),
	)
);
