<?php
/**
 * Shared template helpers. Grows one function per phase of the migration
 * plan rather than all at once, so each addition can be checked against
 * the specific template that needs it.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * The mega-menu in header.php is hand-authored markup (see the note in
 * inc/theme-setup.php for why), so "is this the current nav item" can't
 * come from wp_nav_menu()'s own current-menu-item class. Compares the
 * current request path against the path each nav link points to.
 *
 * @param string $path Site-relative path the nav link points to, e.g. '/services/usability-testing/'.
 */
function peepal_nav_is_here( string $path ): bool {
	$request_uri = isset( $_SERVER['REQUEST_URI'] ) ? sanitize_text_field( wp_unslash( $_SERVER['REQUEST_URI'] ) ) : '';
	$current     = untrailingslashit( (string) wp_parse_url( $request_uri, PHP_URL_PATH ) );
	$target      = untrailingslashit( $path );

	return $current === $target;
}

/**
 * Echoes ' is-here' (class) when the given nav path matches the current
 * request, matching the static site's own is-here/aria-current pairing.
 */
function peepal_nav_class( string $path ): void {
	echo peepal_nav_is_here( $path ) ? ' is-here' : ''; // phpcs:ignore WordPress.Security.EscapeOutput -- static string, no user input.
}

/**
 * Echoes a full aria-current="page" attribute when the given nav path
 * matches the current request, otherwise nothing.
 */
function peepal_nav_aria_current( string $path ): void {
	echo peepal_nav_is_here( $path ) ? ' aria-current="page"' : ''; // phpcs:ignore WordPress.Security.EscapeOutput -- static string, no user input.
}

/**
 * Builds the case-study in-page tab bar (nav.csnav#csNav > .csnav__tab)
 * that main.js's "STICKY TAB BARS" / "SECTION DRIFT" modules expect,
 * reading it out of the rendered content rather than a separate field.
 * Every case-study body pattern in inc/block-patterns.php wraps its
 * section in <section id="..."><h2 class="cs__label">Title</h2>..., so
 * this only has to match that one consistent shape.
 *
 * @param string $rendered_content Output of apply_filters( 'the_content', $post->post_content ).
 */
function peepal_build_csnav( string $rendered_content ): string {
	$found = preg_match_all(
		'/<section[^>]*\bid="([^"]+)"[^>]*>\s*<h2 class="cs__label">(.*?)<\/h2>/s',
		$rendered_content,
		$matches
	);

	if ( ! $found ) {
		return '';
	}

	$tabs = '';
	foreach ( $matches[1] as $index => $section_id ) {
		$tabs .= sprintf(
			'<li><a class="csnav__tab" href="#%1$s">%2$s</a></li>',
			esc_attr( $section_id ),
			wp_strip_all_tags( $matches[2][ $index ] )
		);
	}

	return '<nav class="csnav" id="csNav" aria-label="' . esc_attr__( 'Sections of this case study', 'peepal-design' ) . '"><ul class="csnav__row">' . $tabs . '</ul></nav>';
}

/**
 * contact-sheet.css has two rules that require the FAQ section to sit as
 * a direct child of <main>, not nested inside <article> (`main > #faq:
 * last-child` for the bottom-of-page spacing fix, in particular) — see
 * the CSS around line 2567. Since post_content now carries the FAQ
 * section as part of one continuous flexible body, this splits it back
 * out so single-service.php / single-training.php can close </article>
 * before the FAQ and reproduce the exact DOM the CSS was written against,
 * without touching contact-sheet.css itself.
 *
 * @param string $rendered_content Output of apply_filters( 'the_content', $post->post_content ).
 * @return array{0: string, 1: string} [ content with the FAQ section removed, the FAQ section's own markup (or '' if none found) ].
 */
function peepal_split_content_faq( string $rendered_content ): array {
	$found = preg_match(
		'/<section\b[^>]*\bid="faq"[^>]*>.*?<\/section>/s',
		$rendered_content,
		$match
	);

	if ( ! $found ) {
		return array( $rendered_content, '' );
	}

	$body = str_replace( $match[0], '', $rendered_content );

	return array( $body, $match[0] );
}

/**
 * Blog post table of contents (nav#toc). main.js's "ARTICLE CONTENTS"
 * module expects #toc to already contain <a href="#slug"> links matching
 * real heading ids — it doesn't generate them. Rather than ask a content
 * editor to hand-maintain a duplicate list, this builds it from whichever
 * H2 headings in the post actually have an HTML anchor set (the Heading
 * block's own "Advanced" panel field: Anchor) — no custom pattern needed,
 * this is a native block editor feature.
 *
 * @param string $rendered_content Output of apply_filters( 'the_content', $post->post_content ).
 */
function peepal_build_toc( string $rendered_content ): string {
	$found = preg_match_all(
		'/<h2[^>]*\bid="([^"]+)"[^>]*>(.*?)<\/h2>/s',
		$rendered_content,
		$matches
	);

	if ( ! $found ) {
		return '';
	}

	$items = '';
	foreach ( $matches[1] as $index => $heading_id ) {
		$items .= sprintf(
			'<li><a href="#%1$s">%2$s</a></li>',
			esc_attr( $heading_id ),
			wp_strip_all_tags( $matches[2][ $index ] )
		);
	}

	return '<nav class="toc" id="toc" aria-labelledby="tocH"><p class="toc__h" id="tocH">' . esc_html__( 'Contents', 'peepal-design' ) . '</p><ol class="toc__list">' . $items . '</ol></nav>';
}

/**
 * Word-count-based read time, replacing the static site's hand-typed
 * "X min read" meta field with a computed value — matches .pcard__meta /
 * .artmeta's read-time text.
 */
function peepal_read_time( int $post_id ): string {
	$word_count = str_word_count( wp_strip_all_tags( get_post_field( 'post_content', $post_id ) ) );
	$minutes    = max( 1, (int) round( $word_count / 200 ) );

	/* translators: %d is the number of minutes. */
	return sprintf( _n( '%d min read', '%d min read', $minutes, 'peepal-design' ), $minutes );
}

