<?php
/**
 * Case studies. Rewrite base /case-studies/{slug}/. The listing page
 * (page-portfolio.php) queries this post type directly rather than a
 * separate "portfolio item" type — there is only ever one canonical
 * representation of a case study, whether it's shown as a card or as the
 * full page.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

function peepal_register_cpt_case_study(): void {
	register_post_type(
		'case_study',
		array(
			'labels'       => array(
				'name'          => __( 'Case Studies', 'peepal-design' ),
				'singular_name' => __( 'Case Study', 'peepal-design' ),
				'add_new_item'  => __( 'Add New Case Study', 'peepal-design' ),
				'edit_item'     => __( 'Edit Case Study', 'peepal-design' ),
				'all_items'     => __( 'Case Studies', 'peepal-design' ),
			),
			'public'       => true,
			'has_archive'  => false, // page-portfolio.php is the listing, not a native archive-case_study.php.
			'show_in_rest' => true,
			'menu_icon'    => 'dashicons-portfolio',
			'supports'     => array( 'title', 'editor', 'excerpt', 'thumbnail', 'page-attributes' ),
			'rewrite'      => array( 'slug' => 'case-studies' ),
		)
	);
}
add_action( 'init', 'peepal_register_cpt_case_study' );

function peepal_register_taxonomy_case_category(): void {
	register_taxonomy(
		'case_category',
		'case_study',
		array(
			'labels'       => array( 'name' => __( 'Case Study Categories', 'peepal-design' ) ),
			'public'       => true,
			'show_in_rest' => true,
			'hierarchical' => false, // drives the portfolio filter chips as a flat tag-like list (data-cats), matching the static site's free-text tag string.
			'rewrite'      => array( 'slug' => 'case-category' ),
		)
	);
}
add_action( 'init', 'peepal_register_taxonomy_case_category' );

peepal_register_meta_box(
	'case_study',
	'peepal_case_study_details',
	__( 'Case study card details', 'peepal-design' ),
	array(
		'peepal_code'                => array(
			'label'       => __( 'Kicker / code', 'peepal-design' ),
			'type'        => 'text',
			'description' => __( 'The small eyebrow label on the card, e.g. "MERA BAJAJ APP" (matches case__code).', 'peepal-design' ),
		),
		'peepal_monogram'            => array(
			'label'       => __( 'Carousel monogram', 'peepal-design' ),
			'type'        => 'text',
			'description' => __( 'Two-letter mark shown on the case-studies carousel card, e.g. "MB" for Mera Bajaj. Hand-picked, not auto-derived from the title — the static site\'s own marks (TP, CL, RR, MB) don\'t follow one consistent rule.', 'peepal-design' ),
		),
		'peepal_featured_home'       => array(
			'label'       => __( 'Show in the homepage "Work" grid', 'peepal-design' ),
			'type'        => 'checkbox',
			'description' => __( 'Card fields there come from Title, Excerpt, and Case Study Categories (as the tag) — same data as everywhere else, just a different card layout.', 'peepal-design' ),
		),
		'peepal_home_client'         => array(
			'label'       => __( 'Homepage client name', 'peepal-design' ),
			'type'        => 'text',
			'description' => __( 'The all-caps client name shown on the homepage Work card, e.g. "META". Leave blank to use the title instead.', 'peepal-design' ),
		),
		'peepal_featured_in_carousel' => array(
			'label'       => __( 'Show in the "Case studies" carousel on service &amp; training pages', 'peepal-design' ),
			'type'        => 'checkbox',
			'description' => __( 'The static site reused the same 4 case studies in every carousel — check this on whichever case studies should appear there.', 'peepal-design' ),
		),
		'peepal_is_placeholder'      => array(
			'label'       => __( 'Placeholder card (no case study page written yet)', 'peepal-design' ),
			'type'        => 'checkbox',
			'description' => __( 'Card links to the contact section instead of this post — matches the "dummy case study" cards on the static portfolio page.', 'peepal-design' ),
		),
		'peepal_pitch_heading'       => array(
			'label'       => __( 'Closing CTA heading', 'peepal-design' ),
			'type'        => 'text',
			'description' => __( 'The bold question at the end of the case study, above "Similar case studies" (matches pitch__h). Leave blank to fall back to a generic line.', 'peepal-design' ),
		),
		'peepal_pitch_body'          => array(
			'label'       => __( 'Closing CTA body', 'peepal-design' ),
			'type'        => 'textarea',
			'description' => __( 'One or two sentences under the heading (matches pitch__p).', 'peepal-design' ),
		),
		'peepal_pitch_cta_label'     => array(
			'label'       => __( 'Closing CTA button label', 'peepal-design' ),
			'type'        => 'text',
			'description' => __( 'Defaults to "Get in touch" if left blank. Always links to the homepage contact section.', 'peepal-design' ),
		),
	)
);
