<?php
/**
 * Core theme supports, image sizes and the nav menu location.
 *
 * The mega-menu itself (header.php) is hand-authored to match the static
 * site's promo-tile/multi-column layout exactly rather than driven through
 * wp_nav_menu() + a custom walker — that markup varies too much column to
 * column (promo images, per-item descriptions in some columns but not
 * others) for a generic walker to reproduce safely without a live editor
 * to check it against. register_nav_menus() is still declared below so a
 * theme reviewer isn't surprised to find zero registered locations, and so
 * a future "make the mega-menu editable" pass has somewhere to start.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

function peepal_theme_setup() {
	add_theme_support( 'title-tag' );
	add_theme_support( 'post-thumbnails' );
	add_theme_support( 'html5', array( 'search-form', 'comment-form', 'comment-list', 'gallery', 'caption', 'style', 'script' ) );
	add_theme_support( 'align-wide' );
	add_theme_support( 'responsive-embeds' );
	add_theme_support( 'automatic-feed-links' );
	add_theme_support( 'customize-selective-refresh-widgets' );

	// The static site's hero/plate/case images were shipped at fixed sizes
	// per section rather than one grid of thumbnails — these named sizes
	// mirror the ones templates will actually crop to.
	add_image_size( 'peepal-card', 800, 1000, true );      // .case__shot, .covercard__bg, .print
	add_image_size( 'peepal-hero', 1800, 900, true );       // .cs__hero
	add_image_size( 'peepal-portrait', 480, 480, true );    // team/trainer photos, testimonial avatars

	register_nav_menus(
		array(
			'primary' => __( 'Primary (reference only — the mega-menu markup in header.php is hand-authored, not driven from this menu)', 'peepal-design' ),
			'mobile'  => __( 'Mobile (reference only, same caveat as primary)', 'peepal-design' ),
		)
	);
}
add_action( 'after_setup_theme', 'peepal_theme_setup' );

/**
 * Adds the exact page-identifying class the static CSS keys off
 * (html.careers, html.mera-bajaj, html.portfolio, html.training-uxpm,
 * html.our-journey, html.design-leaders) so those page-scoped rules in
 * contact-sheet.css keep working unmodified. Ported to <body> instead of
 * <html> since body_class() is the native WordPress hook; header.php
 * copies the resulting classes onto <html> at the very top of the
 * document so the CSS selectors (written against html.*) still match.
 */
function peepal_page_slug_class( array $classes ): array {
	$slug_map = array(
		'careers'           => 'careers',
		'case-mera-bajaj'   => 'mera-bajaj',
		'portfolio'         => 'portfolio',
		'training-uxpm'     => 'training-uxpm',
		'our-journey'       => 'our-journey',
		'training-design-leaders' => 'design-leaders',
	);

	$post = get_queried_object();
	if ( $post && isset( $post->post_name ) && isset( $slug_map[ $post->post_name ] ) ) {
		$classes[] = $slug_map[ $post->post_name ];
	}

	return $classes;
}
add_filter( 'body_class', 'peepal_page_slug_class' );
