<?php
/**
 * Service pages. Rewrite base matches header.php's hardcoded mega-menu
 * links (/services/{slug}/), where {slug} is the static filename with the
 * "service-" prefix dropped (service-usability-testing.html -> usability-testing).
 *
 * The body (definition/why/principles/demo/faq, in whatever order and
 * combination a given service needs — see the plan's note on how much
 * these vary page to page) is the native post_content, authored with the
 * Block Patterns registered in inc/block-patterns.php. Only the parts
 * that sit outside that flexible flow — the intro line under the title,
 * and the featured image used as the hero — are real fields.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

function peepal_register_cpt_service(): void {
	register_post_type(
		'service',
		array(
			'labels'       => array(
				'name'          => __( 'Services', 'peepal-design' ),
				'singular_name' => __( 'Service', 'peepal-design' ),
				'add_new_item'  => __( 'Add New Service', 'peepal-design' ),
				'edit_item'     => __( 'Edit Service', 'peepal-design' ),
				'all_items'     => __( 'Services', 'peepal-design' ),
			),
			'public'       => true,
			'has_archive'  => false, // reached only via the mega-menu today, no /services/ index on the static site.
			'show_in_rest' => true,
			'menu_icon'    => 'dashicons-lightbulb',
			'supports'     => array( 'title', 'editor', 'excerpt', 'thumbnail', 'page-attributes' ),
			'rewrite'      => array( 'slug' => 'services' ),
		)
	);
}
add_action( 'init', 'peepal_register_cpt_service' );

function peepal_register_taxonomy_service_category(): void {
	register_taxonomy(
		'service_category',
		'service',
		array(
			'labels'       => array( 'name' => __( 'Service Categories', 'peepal-design' ) ),
			'public'       => true,
			'show_in_rest' => true,
			'hierarchical' => true,
			'rewrite'      => array( 'slug' => 'service-category' ),
		)
	);
}
add_action( 'init', 'peepal_register_taxonomy_service_category' );

peepal_register_meta_box(
	'service',
	'peepal_service_details',
	__( 'Service page details', 'peepal-design' ),
	array(
		'peepal_intro'         => array(
			'label'       => __( 'Intro paragraph', 'peepal-design' ),
			'type'        => 'textarea',
			'description' => __( 'Shown directly under the title, above the hero image (matches cs__intro on the static site).', 'peepal-design' ),
		),
		'peepal_pitch_heading' => array(
			'label'       => __( 'Closing CTA heading', 'peepal-design' ),
			'type'        => 'text',
			'description' => __( 'The bold question at the end of the page, above the case-studies carousel and FAQ (matches pitch__h). Leave blank to fall back to a generic "Ready to talk?" line.', 'peepal-design' ),
		),
		'peepal_pitch_body'    => array(
			'label'       => __( 'Closing CTA body', 'peepal-design' ),
			'type'        => 'textarea',
			'description' => __( 'One or two sentences under the heading (matches pitch__p).', 'peepal-design' ),
		),
		'peepal_pitch_cta_label' => array(
			'label'       => __( 'Closing CTA button label', 'peepal-design' ),
			'type'        => 'text',
			'description' => __( 'Defaults to "Get in touch" if left blank. Always links to the homepage contact section.', 'peepal-design' ),
		),
	)
);
