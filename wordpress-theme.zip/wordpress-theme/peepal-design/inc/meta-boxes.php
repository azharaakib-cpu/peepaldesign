<?php
/**
 * One generic, reusable meta box renderer/saver used by every CPT in this
 * theme instead of a bespoke add_meta_box() + save handler per post type.
 * Deliberately plain (text/textarea/checkbox only) — nothing here needs a
 * repeater, and a hand-rolled repeater UI is exactly the kind of thing
 * this theme is avoiding building blind (see the plan's architecture
 * note on why ACF/Flexible Content was passed over).
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * @param string $post_type The post type this box appears on.
 * @param string $box_id    Unique id for the metabox + its nonce.
 * @param string $title     Metabox title shown in the editor.
 * @param array  $fields    meta_key => array( 'label' => string, 'type' => 'text'|'textarea'|'checkbox', 'description' => string ).
 */
function peepal_register_meta_box( string $post_type, string $box_id, string $title, array $fields ): void {
	add_action(
		'add_meta_boxes',
		function () use ( $post_type, $box_id, $title, $fields ) {
			add_meta_box(
				$box_id,
				$title,
				function ( WP_Post $post ) use ( $box_id, $fields ) {
					wp_nonce_field( 'peepal_save_' . $box_id, 'peepal_nonce_' . $box_id );
					foreach ( $fields as $key => $field ) {
						$value = get_post_meta( $post->ID, $key, true );
						$type  = $field['type'] ?? 'text';
						echo '<p><label for="' . esc_attr( $key ) . '"><strong>' . esc_html( $field['label'] ) . '</strong></label><br>';
						if ( 'checkbox' === $type ) {
							echo '<label><input type="checkbox" id="' . esc_attr( $key ) . '" name="' . esc_attr( $key ) . '" value="1" ' . checked( '1', $value, false ) . '> ' . esc_html( $field['description'] ?? '' ) . '</label>';
						} elseif ( 'textarea' === $type ) {
							echo '<textarea id="' . esc_attr( $key ) . '" name="' . esc_attr( $key ) . '" rows="3" style="width:100%;">' . esc_textarea( $value ) . '</textarea>';
						} else {
							echo '<input type="text" id="' . esc_attr( $key ) . '" name="' . esc_attr( $key ) . '" value="' . esc_attr( $value ) . '" style="width:100%;">';
						}
						if ( 'checkbox' !== $type && ! empty( $field['description'] ) ) {
							echo '<br><span class="description">' . esc_html( $field['description'] ) . '</span>';
						}
						echo '</p>';
					}
				},
				$post_type,
				'normal',
				'high'
			);
		}
	);

	add_action(
		'save_post_' . $post_type,
		function ( int $post_id ) use ( $box_id, $fields ) {
			$nonce_field = 'peepal_nonce_' . $box_id;
			if ( ! isset( $_POST[ $nonce_field ] ) || ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST[ $nonce_field ] ) ), 'peepal_save_' . $box_id ) ) {
				return;
			}
			if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) {
				return;
			}
			if ( ! current_user_can( 'edit_post', $post_id ) ) {
				return;
			}
			foreach ( $fields as $key => $field ) {
				$type = $field['type'] ?? 'text';
				if ( 'checkbox' === $type ) {
					update_post_meta( $post_id, $key, isset( $_POST[ $key ] ) ? '1' : '0' );
					continue;
				}
				if ( ! isset( $_POST[ $key ] ) ) {
					continue;
				}
				$raw   = wp_unslash( $_POST[ $key ] );
				$clean = 'textarea' === $type ? sanitize_textarea_field( $raw ) : sanitize_text_field( $raw );
				update_post_meta( $post_id, $key, $clean );
			}
		}
	);
}
