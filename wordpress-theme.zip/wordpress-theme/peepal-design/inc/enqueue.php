<?php
/**
 * Ports assets/css/contact-sheet.css and assets/js/main.js verbatim as
 * static enqueued assets — see the plan's architecture note on why these
 * two files need zero rewriting: no build step, no server templating
 * markers in either file. Cache-busting uses filemtime() of the actual
 * shipped file instead of a hand-maintained ?v= number, since there's no
 * running site here to remember to bump it on every future edit.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

function peepal_enqueue_assets() {
	$css_path = PEEPAL_THEME_DIR . '/assets/css/contact-sheet.css';
	$js_path  = PEEPAL_THEME_DIR . '/assets/js/main.js';

	wp_enqueue_style(
		'peepal-contact-sheet',
		PEEPAL_THEME_URI . '/assets/css/contact-sheet.css',
		array(),
		file_exists( $css_path ) ? filemtime( $css_path ) : PEEPAL_THEME_VERSION
	);

	// In footer, matching the static markup's own placement of the single
	// <script> tag just before </body> so DOM-ready assumptions inside
	// main.js (it queries elements without waiting on DOMContentLoaded in
	// several modules) keep holding.
	wp_enqueue_script(
		'peepal-main',
		PEEPAL_THEME_URI . '/assets/js/main.js',
		array(),
		file_exists( $js_path ) ? filemtime( $js_path ) : PEEPAL_THEME_VERSION,
		true
	);
}
add_action( 'wp_enqueue_scripts', 'peepal_enqueue_assets' );
