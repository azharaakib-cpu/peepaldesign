<?php
/**
 * Job openings. No public single-post template on purpose — the static
 * site never gave a job its own page, only a modal populated from a
 * hidden <template> on the careers page (see page-careers.php), so
 * 'publicly_queryable' stays false and there is no single-job_opening.php.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

function peepal_register_cpt_job_opening(): void {
	register_post_type(
		'job_opening',
		array(
			'labels'              => array(
				'name'          => __( 'Job Openings', 'peepal-design' ),
				'singular_name' => __( 'Job Opening', 'peepal-design' ),
				'add_new_item'  => __( 'Add New Job Opening', 'peepal-design' ),
				'edit_item'     => __( 'Edit Job Opening', 'peepal-design' ),
				'all_items'     => __( 'Job Openings', 'peepal-design' ),
			),
			'public'              => false,
			'publicly_queryable'  => false,
			'show_ui'             => true,
			'show_in_menu'        => true,
			'show_in_rest'        => true,
			'menu_icon'           => 'dashicons-businessman',
			'supports'            => array( 'title', 'editor', 'excerpt', 'page-attributes' ),
		)
	);
}
add_action( 'init', 'peepal_register_cpt_job_opening' );

function peepal_register_taxonomy_job_function(): void {
	register_taxonomy(
		'job_function',
		'job_opening',
		array(
			'labels'       => array( 'name' => __( 'Job Functions', 'peepal-design' ) ),
			'public'       => false,
			'show_ui'      => true,
			'show_in_rest' => true,
			'hierarchical' => false,
		)
	);
}
add_action( 'init', 'peepal_register_taxonomy_job_function' );

peepal_register_meta_box(
	'job_opening',
	'peepal_job_details',
	__( 'Job card details', 'peepal-design' ),
	array(
		'peepal_location'   => array(
			'label'       => __( 'Location', 'peepal-design' ),
			'type'        => 'text',
			'description' => __( 'e.g. "Remote / Hybrid" (matches job__meta).', 'peepal-design' ),
		),
		'peepal_experience' => array(
			'label'       => __( 'Experience range', 'peepal-design' ),
			'type'        => 'text',
			'description' => __( 'e.g. "5–6 years".', 'peepal-design' ),
		),
	)
);
