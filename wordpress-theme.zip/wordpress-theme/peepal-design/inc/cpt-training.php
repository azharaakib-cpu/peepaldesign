<?php
/**
 * Training programmes. Rewrite base /trainings/{slug}/, matching
 * header.php's mega-menu links. Structurally these overlap each other
 * even less than the 16 service pages do (see the plan's survey notes —
 * nutshell/agenda/audience/gains/challenges/trainers in varying
 * combinations, no two pages alike), so like Service this is title +
 * intro + featured image + fully flexible post_content. No dedicated
 * "agenda" or "trainers grid" pattern beyond what's already registered:
 * an agenda module reuses the FAQ pattern's .qa markup with an extra
 * qa--mod class added by hand, and peepal/crew-grid (below) covers the
 * repeating trainer-card layout.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

function peepal_register_cpt_training(): void {
	register_post_type(
		'training',
		array(
			'labels'       => array(
				'name'          => __( 'Trainings', 'peepal-design' ),
				'singular_name' => __( 'Training', 'peepal-design' ),
				'add_new_item'  => __( 'Add New Training', 'peepal-design' ),
				'edit_item'     => __( 'Edit Training', 'peepal-design' ),
				'all_items'     => __( 'Trainings', 'peepal-design' ),
			),
			'public'       => true,
			'has_archive'  => false,
			'show_in_rest' => true,
			'menu_icon'    => 'dashicons-welcome-learn-more',
			'supports'     => array( 'title', 'editor', 'excerpt', 'thumbnail', 'page-attributes' ),
			'rewrite'      => array( 'slug' => 'trainings' ),
		)
	);
}
add_action( 'init', 'peepal_register_cpt_training' );

peepal_register_meta_box(
	'training',
	'peepal_training_details',
	__( 'Training page details', 'peepal-design' ),
	array(
		'peepal_intro'           => array(
			'label'       => __( 'Intro paragraph', 'peepal-design' ),
			'type'        => 'textarea',
			'description' => __( 'Shown directly under the title, above the hero image.', 'peepal-design' ),
		),
		'peepal_pitch_heading'   => array(
			'label' => __( 'Closing CTA heading', 'peepal-design' ),
			'type'  => 'text',
		),
		'peepal_pitch_body'      => array(
			'label' => __( 'Closing CTA body', 'peepal-design' ),
			'type'  => 'textarea',
		),
		'peepal_pitch_cta_label' => array(
			'label' => __( 'Closing CTA button label', 'peepal-design' ),
			'type'  => 'text',
		),
	)
);
