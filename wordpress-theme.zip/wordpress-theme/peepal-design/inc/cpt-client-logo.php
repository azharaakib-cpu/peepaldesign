<?php
/**
 * Homepage "Trusted by" logo wall. Title = client name (used as the
 * text fallback / alt text), featured image = the logo file.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

function peepal_register_cpt_client_logo(): void {
	register_post_type(
		'client_logo',
		array(
			'labels'             => array(
				'name'          => __( 'Client Logos', 'peepal-design' ),
				'singular_name' => __( 'Client Logo', 'peepal-design' ),
				'add_new_item'  => __( 'Add New Client Logo', 'peepal-design' ),
				'edit_item'     => __( 'Edit Client Logo', 'peepal-design' ),
				'all_items'     => __( 'Client Logos', 'peepal-design' ),
			),
			'public'             => false,
			'publicly_queryable' => false,
			'show_ui'            => true,
			'show_in_menu'       => true,
			'show_in_rest'       => true,
			'menu_icon'          => 'dashicons-building',
			'supports'           => array( 'title', 'thumbnail', 'page-attributes' ),
		)
	);
}
add_action( 'init', 'peepal_register_cpt_client_logo' );
