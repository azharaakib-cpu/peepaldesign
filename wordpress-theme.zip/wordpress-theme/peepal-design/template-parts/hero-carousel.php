<?php
/**
 * The full-bleed image carousel (.peek) shared by the Careers and Our
 * Journey pages. Include with:
 *   get_template_part( 'template-parts/hero-carousel', null, array(
 *       'images' => array( 'careers/hero-1.jpeg', 'careers/hero-2.jpeg', ... ), // relative to /assets/img/
 *       'label'  => 'Life at Peepal Design',
 *   ) );
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$peepal_assets = PEEPAL_THEME_URI . '/assets';
$peepal_images = $args['images'] ?? array();
$peepal_label  = $args['label'] ?? '';

if ( ! $peepal_images ) {
	return;
}
?>
<div class="peek" data-carousel aria-roledescription="carousel" aria-label="<?php echo esc_attr( $peepal_label ); ?>">
  <ul class="peek__track">
    <?php foreach ( $peepal_images as $peepal_index => $peepal_image ) : ?>
    <li class="peek__slide" role="tabpanel" aria-roledescription="slide" aria-label="<?php echo esc_attr( ( $peepal_index + 1 ) . ' of ' . count( $peepal_images ) ); ?>">
      <img class="peek__img" src="<?php echo esc_url( $peepal_assets . '/img/' . ltrim( $peepal_image, '/' ) ); ?>"
           alt="" width="1376" height="768" loading="<?php echo 0 === $peepal_index ? 'eager' : 'lazy'; ?>" decoding="async">
    </li>
    <?php endforeach; ?>
  </ul>
  <div class="peek__dots" role="tablist" aria-label="<?php esc_attr_e( 'Slides', 'peepal-design' ); ?>">
    <?php foreach ( $peepal_images as $peepal_index => $peepal_image ) : ?>
    <button class="peek__dot<?php echo 0 === $peepal_index ? ' is-on' : ''; ?>" type="button" role="tab" aria-selected="<?php echo 0 === $peepal_index ? 'true' : 'false'; ?>" aria-label="<?php echo esc_attr( sprintf( __( 'Go to slide %d', 'peepal-design' ), $peepal_index + 1 ) ); ?>"></button>
    <?php endforeach; ?>
  </div>
</div>
