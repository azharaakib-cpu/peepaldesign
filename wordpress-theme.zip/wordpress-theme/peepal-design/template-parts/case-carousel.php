<?php
/**
 * The "Case studies" carousel reused on every service/training page
 * (.covercarousel > .covercards[data-auto-carousel] of .covercard links).
 * The static site hand-picked the same 4 case studies everywhere rather
 * than curating per page — reproduced here as a query for whichever
 * case_study posts have peepal_featured_in_carousel checked, newest
 * first, so there's one place (the case study's own edit screen) that
 * controls what shows up, not a per-page picker.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$peepal_carousel_query = new WP_Query(
	array(
		'post_type'      => 'case_study',
		'post_status'    => 'publish',
		'posts_per_page' => 6,
		'orderby'        => 'menu_order date',
		'order'          => 'ASC',
		'meta_key'       => 'peepal_featured_in_carousel', // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_key -- small, infrequent CPT; not worth a dedicated taxonomy just for this flag.
		'meta_value'     => '1', // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_value
	)
);

if ( ! $peepal_carousel_query->have_posts() ) {
	return;
}
?>
<section class="cs develop" id="case-studies">
  <header class="secthead secthead--reel" data-drift>
    <div>
      <h2 class="secthead__h"><?php esc_html_e( 'Case studies', 'peepal-design' ); ?></h2>
    </div>
    <div class="covercarousel__nav">
      <button class="covercarousel__arrow" type="button" data-carousel-prev aria-label="<?php esc_attr_e( 'Previous case study', 'peepal-design' ); ?>">
        <svg viewBox="0 0 16 12" aria-hidden="true"><path d="M15 6H1M6 1 1 6l5 5" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg>
      </button>
      <button class="covercarousel__arrow" type="button" data-carousel-next aria-label="<?php esc_attr_e( 'Next case study', 'peepal-design' ); ?>">
        <svg viewBox="0 0 16 12" aria-hidden="true"><path d="M1 6h14M10 1l5 5-5 5" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg>
      </button>
    </div>
  </header>
  <div class="covercarousel">
    <div class="covercards" data-auto-carousel>
      <?php
      $peepal_delay = 0;
      while ( $peepal_carousel_query->have_posts() ) :
          $peepal_carousel_query->the_post();
          $peepal_is_placeholder = '1' === get_post_meta( get_the_ID(), 'peepal_is_placeholder', true );
          $peepal_href           = $peepal_is_placeholder ? home_url( '/#contact' ) : get_permalink();
          $peepal_monogram       = get_post_meta( get_the_ID(), 'peepal_monogram', true );
          ?>
      <a class="covercard develop" href="<?php echo esc_url( $peepal_href ); ?>" data-delay="<?php echo esc_attr( $peepal_delay ); ?>">
        <?php if ( has_post_thumbnail() ) : ?>
        <?php echo wp_get_attachment_image( get_post_thumbnail_id(), 'peepal-card', false, array( 'class' => 'covercard__bg', 'alt' => '' ) ); ?>
        <?php endif; ?>
        <span class="covercard__wash" aria-hidden="true"></span>
        <?php if ( $peepal_monogram ) : ?>
        <span class="covercard__mark" aria-hidden="true"><?php echo esc_html( $peepal_monogram ); ?></span>
        <?php endif; ?>
        <span class="covercard__panel">
          <span class="covercard__title"><?php the_title(); ?></span>
          <span class="covercard__desc"><?php echo esc_html( get_the_excerpt() ); ?></span>
          <span class="covercard__cta"><?php esc_html_e( 'Read case study', 'peepal-design' ); ?><svg viewBox="0 0 16 10" aria-hidden="true"><path d="M0 5h14M10 1l4 4-4 4" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg></span>
        </span>
      </a>
      <?php ++$peepal_delay; endwhile; wp_reset_postdata(); ?>
    </div>
  </div>
</section>
