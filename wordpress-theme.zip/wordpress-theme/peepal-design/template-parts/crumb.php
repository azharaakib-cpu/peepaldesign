<?php
/**
 * Breadcrumb (.cs__crumb). Include with:
 *   get_template_part( 'template-parts/crumb', null, array(
 *       'label' => 'Our Services',
 *       'url'   => home_url( '/#services' ),
 *   ) );
 * $args['label']/$args['url'] describe the middle crumb; the current
 * page's title is read straight from the queried object.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$peepal_label = $args['label'] ?? '';
$peepal_url   = $args['url'] ?? '';
?>
<nav class="cs__crumb" aria-label="Breadcrumb">
  <a href="<?php echo esc_url( home_url( '/' ) ); ?>"><?php esc_html_e( 'Home', 'peepal-design' ); ?></a> <span aria-hidden="true">/</span>
  <?php if ( $peepal_label && $peepal_url ) : ?>
  <a href="<?php echo esc_url( $peepal_url ); ?>"><?php echo esc_html( $peepal_label ); ?></a> <span aria-hidden="true">/</span>
  <?php endif; ?>
  <span aria-current="page"><?php the_title(); ?></span>
</nav>
