<?php
/**
 * Blog post author box (.pauthor). The static site's byline is the studio
 * itself, not a person — "Written by Peepal Design", with a fixed bio and
 * a link to Our Journey — so this is deliberately NOT wired to WP's
 * per-user author fields. If individual bylines are wanted later, swap
 * the constants below for get_the_author_meta() calls.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$peepal_assets = PEEPAL_THEME_URI . '/assets';
?>
<section class="cs develop" id="author">
  <div class="pauthor">
    <span class="pauthor__av" aria-hidden="true">
      <img src="<?php echo esc_url( $peepal_assets . '/brand/logomark.svg' ); ?>" alt="" width="32" height="32"
           onerror="this.onerror=null;this.src='<?php echo esc_url( $peepal_assets . '/brand/logomark.png' ); ?>'">
    </span>
    <div class="pauthor__body">
      <span class="pauthor__code"><?php esc_html_e( 'Written by', 'peepal-design' ); ?></span>
      <h2 class="pauthor__name">Peepal Design</h2>
      <p class="pauthor__bio"><?php esc_html_e( 'A research-first UX studio. Part of Bridged Global — a worldwide network of UX designers and design specialists. Founded 2016, Mumbai, India.', 'peepal-design' ); ?></p>
      <a class="pauthor__go" href="<?php echo esc_url( home_url( '/our-journey/' ) ); ?>"><?php esc_html_e( 'More about the studio', 'peepal-design' ); ?><svg viewBox="0 0 16 10" aria-hidden="true"><path d="M0 5h14M10 1l4 4-4 4" fill="none" stroke="currentColor" stroke-width="1.4" stroke-linecap="round" stroke-linejoin="round"/></svg></a>
    </div>
  </div>
</section>
