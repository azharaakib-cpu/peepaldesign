<?php
/**
 * One .case article — used by both page-portfolio.php's grid and
 * single-case_study.php's "Similar case studies" section. Expects the
 * loop to already be on the right post ( the_post() called ) and reads
 * $args for the two things that differ by context:
 *   'prefix' — the one-letter frame-number prefix ('P' on the portfolio
 *              grid, 'R' on "similar case studies", matching the static
 *              site's own P·01 / R·01 labelling).
 *   'index'  — 1-based position in the current grid/list.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$peepal_prefix = $args['prefix'] ?? 'P';
$peepal_index  = $args['index'] ?? 1;

$peepal_is_placeholder = '1' === get_post_meta( get_the_ID(), 'peepal_is_placeholder', true );
$peepal_href           = $peepal_is_placeholder ? home_url( '/#contact' ) : get_permalink();
$peepal_code           = get_post_meta( get_the_ID(), 'peepal_code', true );
if ( ! $peepal_code ) {
	$peepal_code = get_the_title();
}

$peepal_terms   = get_the_terms( get_the_ID(), 'case_category' );
$peepal_terms   = is_array( $peepal_terms ) ? $peepal_terms : array();
$peepal_slugs   = wp_list_pluck( $peepal_terms, 'slug' );
$peepal_names   = wp_list_pluck( $peepal_terms, 'name' );
?>
<article class="case develop" data-cats="<?php echo esc_attr( implode( ' ', $peepal_slugs ) ); ?>" data-delay="<?php echo esc_attr( ( $peepal_index - 1 ) % 10 ); ?>"<?php echo $peepal_is_placeholder ? ' data-pending' : ''; ?>>
  <a class="case__link" href="<?php echo esc_url( $peepal_href ); ?>">
    <span class="case__plate">
      <?php if ( has_post_thumbnail() ) : ?>
      <?php echo wp_get_attachment_image( get_post_thumbnail_id(), 'peepal-card', false, array( 'class' => 'case__shot', 'alt' => '' ) ); ?>
      <?php endif; ?>
      <span class="case__frameno" aria-hidden="true"><?php echo esc_html( $peepal_prefix . ' · ' . sprintf( '%02d', $peepal_index ) ); ?></span>
    </span>
    <span class="case__meta">
      <span class="case__code"><?php echo esc_html( $peepal_code ); ?></span>
      <span class="case__title"><?php the_title(); ?></span>
      <?php if ( has_excerpt() ) : ?>
      <span class="case__desc"><?php echo esc_html( get_the_excerpt() ); ?></span>
      <?php endif; ?>
      <span class="case__side">
        <?php if ( $peepal_names ) : ?>
        <span class="case__tags"><?php echo esc_html( implode( ' · ', $peepal_names ) ); ?></span>
        <?php endif; ?>
        <span class="case__go" aria-hidden="true"><svg viewBox="0 0 16 10"><path d="M0 5h14M10 1l4 4-4 4" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg></span>
      </span>
    </span>
  </a>
</article>
