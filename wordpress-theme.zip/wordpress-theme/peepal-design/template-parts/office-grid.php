<?php
/**
 * The "cities" grid on Our Global Family (.lvls.lvls--2up of .lvl
 * articles carrying a partner logo instead of plain text). Queries the
 * office CPT directly rather than taking posts as an argument — there's
 * only one place this is used.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$peepal_offices_query = new WP_Query(
	array(
		'post_type'      => 'office',
		'post_status'    => 'publish',
		'posts_per_page' => -1,
		'orderby'        => 'menu_order',
		'order'          => 'ASC',
	)
);

if ( ! $peepal_offices_query->have_posts() ) {
	return;
}
?>
<div class="lvls lvls--2up">
  <?php
  while ( $peepal_offices_query->have_posts() ) :
      $peepal_offices_query->the_post();
      $peepal_link = get_post_meta( get_the_ID(), 'peepal_link', true );
      ?>
  <article class="lvl">
    <?php if ( has_post_thumbnail() ) : ?>
    <?php the_post_thumbnail( 'medium', array( 'class' => 'lvl__logo' ) ); ?>
    <?php endif; ?>
    <h3 class="lvl__title"><?php the_title(); ?></h3>
    <div class="lvl__body"><?php the_content(); ?></div>
    <?php if ( $peepal_link ) : ?>
    <a class="lvl__more" href="<?php echo esc_url( $peepal_link ); ?>"<?php echo ( 0 !== strpos( $peepal_link, home_url() ) ) ? ' target="_blank" rel="noopener noreferrer"' : ''; ?>><?php esc_html_e( 'Visit website', 'peepal-design' ); ?><?php if ( 0 !== strpos( $peepal_link, home_url() ) ) : ?><svg viewBox="0 0 12 12" aria-hidden="true"><path d="M5 7 10.5 1.5M6.75 1.5h3.75v3.75M9 7.75v2.75H1.5V3h2.75" fill="none" stroke="currentColor" stroke-width="1.3" stroke-linecap="round" stroke-linejoin="round"/></svg><span class="vh"> (opens in a new tab)</span><?php endif; ?></a>
    <?php endif; ?>
  </article>
  <?php endwhile; ?>
</div>
<?php wp_reset_postdata(); ?>
