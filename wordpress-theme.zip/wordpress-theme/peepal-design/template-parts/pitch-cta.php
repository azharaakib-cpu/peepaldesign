<?php
/**
 * Closing CTA (.sec--pitch). The static site hand-wrote a different
 * headline/body per page rather than reusing one generic line, so this
 * reads the peepal_pitch_* meta fields (added on the service and
 * case_study CPTs) off the current post and only falls back to a generic
 * line when a page hasn't set its own yet.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$peepal_post_id = get_the_ID();
$peepal_heading = get_post_meta( $peepal_post_id, 'peepal_pitch_heading', true );
$peepal_body    = get_post_meta( $peepal_post_id, 'peepal_pitch_body', true );
$peepal_label   = get_post_meta( $peepal_post_id, 'peepal_pitch_cta_label', true );

if ( ! $peepal_heading ) {
	$peepal_heading = __( 'Ready to talk about your product?', 'peepal-design' );
}
if ( ! $peepal_body ) {
	$peepal_body = __( "Tell us where things stand and we'll help you figure out the fastest way to get evidence you can act on.", 'peepal-design' );
}
if ( ! $peepal_label ) {
	$peepal_label = __( 'Get in touch', 'peepal-design' );
}
?>
<section class="frame sec sec--pitch">
  <div class="pitch">
    <h2 class="pitch__h develop"><?php echo wp_kses_post( $peepal_heading ); ?></h2>
    <p class="pitch__p develop" data-delay="1"><?php echo esc_html( $peepal_body ); ?></p>
    <div class="pitch__cta develop" data-delay="2">
      <a class="btn btn--mark" href="<?php echo esc_url( home_url( '/#contact' ) ); ?>"><?php echo esc_html( $peepal_label ); ?></a>
    </div>
  </div>
</section>
