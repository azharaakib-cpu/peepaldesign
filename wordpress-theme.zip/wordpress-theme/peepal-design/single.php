<?php
/**
 * Single blog post. Body is fully native block-editor content (headings,
 * paragraphs, lists, images, quotes) — nothing here needs a Block Pattern,
 * since long-form freeform writing is exactly what the block editor is
 * for. Give an H2 an "Anchor" (Heading block -> Advanced panel) to have
 * it appear in the auto-built table of contents (peepal_build_toc()).
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

get_header();

while ( have_posts() ) :
	the_post();
	$peepal_rendered = apply_filters( 'the_content', get_the_content() );
	$peepal_toc      = peepal_build_toc( $peepal_rendered );
	$peepal_cats     = get_the_category();
	?>

<article class="frame sec sec--case">
	<nav class="cs__crumb" aria-label="Breadcrumb">
		<a href="<?php echo esc_url( home_url( '/' ) ); ?>"><?php esc_html_e( 'Home', 'peepal-design' ); ?></a> <span aria-hidden="true">/</span>
		<a href="<?php echo esc_url( home_url( '/blog/' ) ); ?>"><?php esc_html_e( 'Insights & Blog', 'peepal-design' ); ?></a> <span aria-hidden="true">/</span>
		<span aria-current="page"><?php echo $peepal_cats ? esc_html( $peepal_cats[0]->name ) : esc_html__( 'Article', 'peepal-design' ); ?></span>
	</nav>

	<header class="arthead">
		<h1 class="arthead__t develop"><?php the_title(); ?></h1>
		<?php if ( has_excerpt() ) : ?>
		<p class="arthead__dek develop" data-delay="1"><?php echo esc_html( get_the_excerpt() ); ?></p>
		<?php endif; ?>

		<div class="artmeta develop" data-delay="2">
			<span class="artmeta__by">
				<span class="artmeta__av" aria-hidden="true">
					<?php echo get_avatar( get_the_author_meta( 'ID' ), 20 ); ?>
				</span>
				<span class="artmeta__who">
					<span class="artmeta__name"><?php the_author(); ?></span>
					<?php if ( $peepal_cats ) : ?>
					<span class="artmeta__role"><?php echo esc_html( $peepal_cats[0]->name ); ?></span>
					<?php endif; ?>
				</span>
			</span>
			<span class="artmeta__sep" aria-hidden="true"></span>
			<time class="artmeta__date" datetime="<?php echo esc_attr( get_the_date( 'c' ) ); ?>"><?php echo esc_html( get_the_date() ); ?></time>
			<span class="artmeta__sep" aria-hidden="true"></span>
			<span class="artmeta__read"><?php echo esc_html( peepal_read_time( get_the_ID() ) ); ?></span>
			<?php if ( $peepal_cats ) : ?>
			<a class="artmeta__tag" href="<?php echo esc_url( get_category_link( $peepal_cats[0] ) ); ?>"><?php echo esc_html( $peepal_cats[0]->name ); ?></a>
			<?php endif; ?>
		</div>
	</header>

	<?php if ( has_post_thumbnail() ) : ?>
	<figure class="arthero develop" data-delay="3">
		<?php the_post_thumbnail( 'large', array( 'fetchpriority' => 'high' ) ); ?>
	</figure>
	<?php endif; ?>

	<div class="artwrap">
		<?php echo $peepal_toc; // phpcs:ignore WordPress.Security.EscapeOutput -- built from esc_attr()/wp_strip_all_tags() output inside peepal_build_toc(). ?>

		<div class="artbody" id="body">
			<?php echo $peepal_rendered; // phpcs:ignore WordPress.Security.EscapeOutput -- already passed through the_content filter chain. ?>
		</div>
	</div>
</article>

<?php get_template_part( 'template-parts/author-box' ); ?>

<?php
endwhile;

get_footer();
