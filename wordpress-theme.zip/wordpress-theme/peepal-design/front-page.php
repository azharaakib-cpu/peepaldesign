<?php
/**
 * Homepage. Unlike every other template so far, most of this page is
 * intentionally hardcoded rather than field-driven — see the plan's
 * "Phase 8" note for why. Two JS modules in particular constrained this:
 *
 * - THE PLATE (the canvas world map) keeps its own hand-tuned CITIES
 *   array (lat/lon plus per-city label-nudge offsets) inside main.js —
 *   not something a content editor filling in a city name could
 *   reasonably also supply, and not something to risk re-deriving here
 *   with no browser to test the canvas render against. The map, city
 *   tag list and citycard panel below are ported byte-for-byte from the
 *   static markup and stay wired to main.js's existing internal data.
 * - SERVICES SCROLL/PIN pairs each .svc__item to a .svc__shot by a
 *   data-svc index — safe to hardcode (matches Careers' identical
 *   "advantage" pairing) but not worth turning into fields for four
 *   items that rarely change.
 *
 * What IS genuinely dynamic, because the JS driving it is index-agnostic
 * and a WP_Query loop is strictly safer than hand-maintained markup:
 * the "Work" grid (case_study posts flagged peepal_featured_home), the
 * clients logo wall (client_logo CPT — main.js's CLIENTS REEL module
 * measures `[data-clients-track]` rows generically, so any count per
 * row works), and the testimonial reel (testimonial CPT).
 *
 * Hero copy: the H1 is frozen, client-approved copy with specific
 * <span class="tok tok--human/ai"> colour-coding baked into fixed words
 * ("human", "AI") — a plain text field can't safely preserve that
 * markup, so it stays hardcoded. The sub-copy, CTA labels and the 4 stat
 * counters are meta fields, pre-filled with the current real copy.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$peepal_assets = PEEPAL_THEME_URI . '/assets';

get_header();

while ( have_posts() ) :
	the_post();

	$peepal_sub = get_post_meta( get_the_ID(), 'peepal_hero_sub', true );
	if ( ! $peepal_sub ) {
		$peepal_sub = __( "We bring real user insights to AI-Native products, helping organisations worldwide create products people TRUST, ADOPT and LOVE.", 'peepal-design' );
	}

	$peepal_stats = array();
	for ( $peepal_i = 1; $peepal_i <= 4; $peepal_i++ ) {
		$peepal_stats[] = array(
			'value'  => get_post_meta( get_the_ID(), "peepal_stat_{$peepal_i}_value", true ),
			'suffix' => get_post_meta( get_the_ID(), "peepal_stat_{$peepal_i}_suffix", true ),
			'label'  => get_post_meta( get_the_ID(), "peepal_stat_{$peepal_i}_label", true ),
		);
	}
	$peepal_stat_defaults = array(
		array( 'value' => '1200', 'suffix' => '+', 'label' => __( 'Research Projects', 'peepal-design' ) ),
		array( 'value' => '200', 'suffix' => '+', 'label' => __( 'Design Engagements', 'peepal-design' ) ),
		array( 'value' => '10000', 'suffix' => '+', 'label' => __( 'User Interviews', 'peepal-design' ) ),
		array( 'value' => '60', 'suffix' => '+', 'label' => __( 'Researchers & Designers', 'peepal-design' ) ),
	);
	foreach ( $peepal_stats as $peepal_i => $peepal_stat ) {
		if ( '' === $peepal_stat['value'] ) {
			$peepal_stats[ $peepal_i ] = $peepal_stat_defaults[ $peepal_i ];
		}
	}
	?>

<section class="frame hero" id="hero">
  <div class="edge"><span class="edge__code"><?php esc_html_e( '15 YEARS OF RESEARCH LED UX DESIGN', 'peepal-design' ); ?></span><span class="edge__ticks"></span></div>
  <div class="hero__vignette" aria-hidden="true"></div>

  <div class="hero__inner">
    <h1 class="hero__h1 develop">
      <span class="ln"><?php esc_html_e( 'Designing', 'peepal-design' ); ?> <span class="tok tok--human"><?php esc_html_e( 'human', 'peepal-design' ); ?></span> <?php esc_html_e( 'experience of', 'peepal-design' ); ?> <span class="tok tok--ai"><?php esc_html_e( 'AI', 'peepal-design' ); ?></span></span>
    </h1>
    <p class="hero__sub develop" data-delay="1"><?php echo esc_html( $peepal_sub ); ?></p>
    <div class="hero__cta develop" data-delay="2">
      <a class="btn btn--mark" href="#work"><?php esc_html_e( 'Explore our work', 'peepal-design' ); ?></a>
      <a class="btn btn--ghost" href="#contact"><?php esc_html_e( 'Start a Project', 'peepal-design' ); ?></a>
    </div>
  </div>

  <div class="counter" id="counter">
    <?php foreach ( $peepal_stats as $peepal_stat ) : ?>
    <div class="counter__item"><span class="counter__n" data-count="<?php echo esc_attr( $peepal_stat['value'] ); ?>" data-suffix="<?php echo esc_attr( $peepal_stat['suffix'] ); ?>">0</span><span class="counter__l"><?php echo esc_html( $peepal_stat['label'] ); ?></span></div>
    <?php endforeach; ?>
  </div>
</section>

<section class="frame sec sec--work" id="work">
  <div class="edge"><span class="edge__code"><?php esc_html_e( 'WORK WE ARE PROUD OF', 'peepal-design' ); ?></span><span class="edge__ticks"></span></div>
  <div class="sec__intro">
    <h2 class="h2 develop"><?php esc_html_e( 'Transforming complex challenges into', 'peepal-design' ); ?> <em><?php esc_html_e( 'Meaningful Experiences', 'peepal-design' ); ?></em></h2>
    <p class="lede develop" data-delay="1"><?php esc_html_e( 'From enterprise AI to consumer products — research-led design that moves people and organisations forward.', 'peepal-design' ); ?></p>
  </div>
  <div class="sheetgrid" id="workGrid">
    <?php
    $peepal_work_query = new WP_Query(
        array(
            'post_type'      => 'case_study',
            'post_status'    => 'publish',
            'posts_per_page' => 4,
            'orderby'        => 'menu_order date',
            'order'          => 'ASC',
            'meta_key'       => 'peepal_featured_home', // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_key
            'meta_value'     => '1', // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_value
        )
    );
    $peepal_work_index = 0;
    while ( $peepal_work_query->have_posts() ) :
        $peepal_work_query->the_post();
        $peepal_client = get_post_meta( get_the_ID(), 'peepal_home_client', true );
        if ( ! $peepal_client ) {
            $peepal_client = get_the_title();
        }
        $peepal_work_terms = get_the_terms( get_the_ID(), 'case_category' );
        $peepal_work_tag   = ( is_array( $peepal_work_terms ) && $peepal_work_terms ) ? $peepal_work_terms[0]->name : '';
        ?>
    <article class="print develop" data-delay="<?php echo esc_attr( $peepal_work_index ); ?>" tabindex="0">
      <div class="print__plate">
        <?php if ( has_post_thumbnail() ) : ?>
        <?php the_post_thumbnail( 'peepal-card', array( 'class' => 'art' ) ); ?>
        <?php endif; ?>
      </div>
      <div class="print__meta">
        <span class="client"><?php echo esc_html( mb_strtoupper( $peepal_client ) ); ?></span>
        <h3><?php the_title(); ?></h3>
        <div class="print__foot"><?php if ( $peepal_work_tag ) : ?><span class="tag"><?php echo esc_html( mb_strtoupper( $peepal_work_tag ) ); ?></span><?php endif; ?><a class="cta-inline" href="<?php the_permalink(); ?>"><?php esc_html_e( 'View Case Study', 'peepal-design' ); ?><svg viewBox="0 0 16 10" aria-hidden="true"><path d="M0 5h14M10 1l4 4-4 4" fill="none" stroke="currentColor" stroke-width="1.4" stroke-linecap="round" stroke-linejoin="round"/></svg></a></div>
      </div>
    </article>
    <?php ++$peepal_work_index; endwhile; wp_reset_postdata(); ?>
  </div>
  <div class="sec__more develop"><a class="btn btn--ghost" href="<?php echo esc_url( home_url( '/portfolio/' ) ); ?>"><?php esc_html_e( 'Explore All Projects', 'peepal-design' ); ?></a></div>
</section>

<section class="frame sec sec--clients" id="clients">
  <div class="edge"><span class="edge__code"><?php esc_html_e( 'TRUSTED BY', 'peepal-design' ); ?></span><span class="edge__ticks"></span></div>
  <div class="clients-pin" data-clients-pin>
    <div class="clients-pin__sticky">
      <div class="sec__intro">
        <h2 class="h2 develop"><?php esc_html_e( "Clients We've", 'peepal-design' ); ?> <em><?php esc_html_e( 'Partnered With', 'peepal-design' ); ?></em></h2>
        <p class="lede lede--wide develop" data-delay="1"><?php esc_html_e( "We are proud to partner with a diverse range of clients, from industry giants to innovative startups. Their logos represent the trust they've placed in us and the successful collaborations we've built together — driving real impact, solving complex challenges, and creating products that users genuinely love.", 'peepal-design' ); ?></p>
      </div>
      <?php
      $peepal_logos_query = new WP_Query(
          array(
              'post_type'      => 'client_logo',
              'post_status'    => 'publish',
              'posts_per_page' => -1,
              'orderby'        => 'menu_order',
              'order'          => 'ASC',
          )
      );
      $peepal_all_logos = $peepal_logos_query->posts;
      $peepal_half      = (int) ceil( count( $peepal_all_logos ) / 2 );
      $peepal_rows      = array_chunk( $peepal_all_logos, max( 1, $peepal_half ) );
      foreach ( $peepal_rows as $peepal_row ) :
          ?>
      <ul class="clients" data-clients-track>
        <?php foreach ( $peepal_row as $peepal_logo_post ) : ?>
        <li class="client-cell">
          <?php if ( has_post_thumbnail( $peepal_logo_post ) ) : ?>
          <?php echo wp_get_attachment_image( get_post_thumbnail_id( $peepal_logo_post ), 'medium', false, array( 'class' => 'client-logo', 'alt' => get_the_title( $peepal_logo_post ), 'loading' => 'lazy' ) ); ?>
          <?php else : ?>
          <span class="client-name"><?php echo esc_html( get_the_title( $peepal_logo_post ) ); ?></span>
          <?php endif; ?>
        </li>
        <?php endforeach; ?>
      </ul>
      <?php endforeach; wp_reset_postdata(); ?>
    </div>
  </div>
</section>

<section class="frame sec sec--services" id="services">
  <div class="edge"><span class="edge__code"><?php esc_html_e( 'WHAT WE DO', 'peepal-design' ); ?></span><span class="edge__ticks"></span></div>
  <div class="svc-pin" data-svc-pin>
    <div class="svc-pin__sticky">
      <div class="sec__intro">
        <h2 class="h2 develop"><?php esc_html_e( 'Bridging the gap between', 'peepal-design' ); ?> <em><?php esc_html_e( 'algorithms and people.', 'peepal-design' ); ?></em></h2>
        <p class="lede lede--wide develop" data-delay="1"><?php esc_html_e( 'We work across the full arc of building AI-native products — from the research that uncovers real behaviour, through strategy and interface design, to the training that helps teams carry it forward.', 'peepal-design' ); ?></p>
      </div>
      <div class="svc">
        <div class="svc__col">
          <div class="svc__track" data-svc-track>
            <?php
            $peepal_service_teasers = array(
                array(
                    'title' => __( 'Research', 'peepal-design' ),
                    'body'  => __( 'Deep ethnographic and behavioural research to understand the friction points in human–AI interaction models.', 'peepal-design' ),
                    'icon'  => '<circle cx="14" cy="14" r="9" fill="none" stroke="currentColor" stroke-width="1.6"/><path d="M20.5 20.5 29 29" stroke="currentColor" stroke-width="1.6" stroke-linecap="round"/><path d="M9 14h10M14 9v10" stroke="currentColor" stroke-width="1.2" opacity=".5"/>',
                    'shot'  => 'services/research.jpg',
                ),
                array(
                    'title' => __( 'UX Strategy', 'peepal-design' ),
                    'body'  => __( 'Defining the product vision for AI-native experiences, aligning business goals with human needs and ethical intent.', 'peepal-design' ),
                    'icon'  => '<path d="M4 26 12 8l8 12 4-6 4 12Z" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linejoin="round"/><path d="M3 29h26" stroke="currentColor" stroke-width="1.2" opacity=".5"/>',
                    'shot'  => 'services/strategy.jpg',
                ),
                array(
                    'title' => __( 'AI Experience Design', 'peepal-design' ),
                    'body'  => __( 'Crafting fluid, conversational and agentic interfaces that protect user agency and keep system behaviour transparent.', 'peepal-design' ),
                    'icon'  => '<rect x="4" y="6" width="24" height="16" rx="2" fill="none" stroke="currentColor" stroke-width="1.6"/><path d="M9 12h9M9 16h6" stroke="currentColor" stroke-width="1.4" stroke-linecap="round"/><path d="M11 22v4M21 22v4M8 27h16" stroke="currentColor" stroke-width="1.2" opacity=".5"/>',
                    'shot'  => 'services/design.jpg',
                ),
                array(
                    'title' => __( 'UXPM Training', 'peepal-design' ),
                    'body'  => __( 'Building AI programme-management capability: frameworks, processes and governance for scaling human-centred design in place.', 'peepal-design' ),
                    'icon'  => '<path d="M16 5 29 11l-13 6-13-6Z" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linejoin="round"/><path d="M8 14v7c0 2.2 3.6 4 8 4s8-1.8 8-4v-7" fill="none" stroke="currentColor" stroke-width="1.6"/>',
                    'shot'  => 'services/training.jpg',
                ),
            );
            foreach ( $peepal_service_teasers as $peepal_index => $peepal_teaser ) :
                ?>
            <article class="svc__item" data-svc="<?php echo esc_attr( $peepal_index ); ?>">
              <svg class="svc__icon" viewBox="0 0 32 32" aria-hidden="true"><?php echo $peepal_teaser['icon']; // phpcs:ignore WordPress.Security.EscapeOutput -- fixed inline SVG path data authored above, no user input. ?></svg>
              <h3><?php echo esc_html( $peepal_teaser['title'] ); ?></h3>
              <p><?php echo esc_html( $peepal_teaser['body'] ); ?></p>
              <span class="learn"><?php esc_html_e( 'Learn more', 'peepal-design' ); ?><svg viewBox="0 0 16 10" aria-hidden="true"><path d="M0 5h14M10 1l4 4-4 4" fill="none" stroke="currentColor" stroke-width="1.4" stroke-linecap="round" stroke-linejoin="round"/></svg></span>
            </article>
            <?php endforeach; ?>
          </div>
        </div>
        <div class="svc__stage" aria-hidden="true">
          <div class="svc__frame">
            <?php foreach ( $peepal_service_teasers as $peepal_index => $peepal_teaser ) : ?>
            <img class="svc__shot<?php echo 0 === $peepal_index ? ' is-on' : ''; ?>" src="<?php echo esc_url( $peepal_assets . '/img/' . $peepal_teaser['shot'] ); ?>" alt="" width="896" height="1200" loading="lazy" decoding="async" data-svc="<?php echo esc_attr( $peepal_index ); ?>">
            <?php endforeach; ?>
            <span class="svc__stamp" id="svcStamp">01 &middot; <?php echo esc_html( $peepal_service_teasers[0]['title'] ); ?></span>
          </div>
        </div>
      </div>
    </div>
  </div>
</section>

<section class="frame sec sec--voices" id="testimonials">
  <div class="edge"><span class="edge__code"><?php esc_html_e( 'CLIENT TESTIMONIALS', 'peepal-design' ); ?></span><span class="edge__ticks"></span></div>
  <div class="sec__intro sec__intro--reel">
    <h2 class="h2 develop"><?php esc_html_e( 'Helping global teams design', 'peepal-design' ); ?> <em><?php esc_html_e( "What's Next", 'peepal-design' ); ?></em></h2>
    <div class="reel__nav develop" data-delay="1">
      <button class="reel__btn" type="button" data-dir="-1" aria-label="<?php esc_attr_e( 'Previous testimonial', 'peepal-design' ); ?>" aria-controls="reelTrack">
        <svg viewBox="0 0 16 12" aria-hidden="true"><path d="M15 6H1M6 1 1 6l5 5" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg>
      </button>
      <button class="reel__btn" type="button" data-dir="1" aria-label="<?php esc_attr_e( 'Next testimonial', 'peepal-design' ); ?>" aria-controls="reelTrack">
        <svg viewBox="0 0 16 12" aria-hidden="true"><path d="M1 6h14M10 1l5 5-5 5" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg>
      </button>
    </div>
  </div>
  <div class="reel develop" data-delay="2">
    <div class="reel__track" id="reelTrack" aria-live="polite">
      <?php
      $peepal_testimonials_query = new WP_Query(
          array(
              'post_type'      => 'testimonial',
              'post_status'    => 'publish',
              'posts_per_page' => -1,
              'orderby'        => 'menu_order',
              'order'          => 'ASC',
          )
      );
      $peepal_testimonial_total = $peepal_testimonials_query->post_count;
      $peepal_testimonial_index = 0;
      while ( $peepal_testimonials_query->have_posts() ) :
          $peepal_testimonials_query->the_post();
          ++$peepal_testimonial_index;
          $peepal_rating = (int) get_post_meta( get_the_ID(), 'peepal_rating', true );
          if ( $peepal_rating < 1 || $peepal_rating > 5 ) {
              $peepal_rating = 5;
          }
          ?>
      <div class="reel__group" role="group" aria-roledescription="slide" aria-label="<?php echo esc_attr( sprintf( __( 'Testimonial %1$d of %2$d', 'peepal-design' ), $peepal_testimonial_index, $peepal_testimonial_total ) ); ?>">
        <figure class="voice voice--quote">
          <span class="voice__frameno" aria-hidden="true"><?php echo esc_html( 'P · ' . sprintf( '%02d', $peepal_testimonial_index ) ); ?></span>
          <svg class="voice__q" viewBox="0 0 48 32" aria-hidden="true"><path d="M4 30c-2-9 0-19 9-27M20 30c-2-9 0-19 9-27" fill="none" stroke="currentColor" stroke-width="3.2" stroke-linecap="round"/></svg>
          <blockquote><?php the_content(); ?></blockquote>
          <div class="stars" role="img" aria-label="<?php echo esc_attr( sprintf( __( 'Rated %d out of 5', 'peepal-design' ), $peepal_rating ) ); ?>">
            <svg viewBox="0 0 100 16" aria-hidden="true"><g fill="currentColor">
              <?php
              $peepal_star_positions = array( 8, 28, 48, 68, 88 );
              foreach ( $peepal_star_positions as $peepal_star_index => $peepal_x ) :
                  if ( $peepal_star_index >= $peepal_rating ) {
                      continue;
                  }
                  ?>
              <path d="M<?php echo esc_attr( $peepal_x ); ?> 1l2.2 4.5 5 .7-3.6 3.5.85 5L<?php echo esc_attr( $peepal_x ); ?> 12.4l-4.45 2.3.85-5-3.6-3.5 5-.7z"/>
              <?php endforeach; ?>
            </g></svg>
          </div>
          <figcaption>
            <span class="voice__who"><span class="voice__name"><?php echo esc_html( get_post_meta( get_the_ID(), 'peepal_author_name', true ) ); ?></span><span class="voice__role"><?php echo esc_html( get_post_meta( get_the_ID(), 'peepal_author_role', true ) ); ?></span></span>
            <?php if ( has_post_thumbnail() ) : ?>
            <span class="voice__org"><?php the_post_thumbnail( 'thumbnail', array( 'class' => 'voice__logo', 'alt' => get_post_meta( get_the_ID(), 'peepal_org_name', true ) ) ); ?></span>
            <?php endif; ?>
          </figcaption>
        </figure>
      </div>
      <?php endwhile; wp_reset_postdata(); ?>
    </div>
  </div>
</section>

<section class="frame sec sec--globe" id="global">
  <div class="edge"><span class="edge__code"><?php esc_html_e( 'GLOBAL REACH', 'peepal-design' ); ?></span><span class="edge__ticks"></span></div>
  <div class="sec__intro">
    <h2 class="h2 develop"><?php esc_html_e( 'Designing for', 'peepal-design' ); ?> <em><?php esc_html_e( 'Humans, Everywhere', 'peepal-design' ); ?></em></h2>
    <p class="lede develop" data-delay="1"><?php esc_html_e( 'Eight cities. Three continents. One mission — to make AI feel more human.', 'peepal-design' ); ?></p>
  </div>

  <div class="citycard" id="cityCard" aria-live="polite">
    <div class="citycard__body">
      <span class="citycard__code" id="cityCardCode">STUDIO</span>
      <h3 class="citycard__name" id="cityCardName">Chicago</h3>
      <p class="citycard__meta" id="cityCardCountry">United States</p>
    </div>
    <a class="citycard__link" id="cityCardLink" href="#global">
      <span id="cityCardLinkText"><?php esc_html_e( 'Website to confirm', 'peepal-design' ); ?></span>
      <svg viewBox="0 0 16 16" aria-hidden="true"><path d="M5 11 11 5M6 5h5v5" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg>
    </a>
  </div>

  <!-- This list's order/index is read directly by main.js's own internal
       CITIES array (data-city="0"-"7") — see the file header note on why
       that array stays in main.js rather than becoming CMS content. -->
  <ul class="cities" id="cityTags">
    <?php foreach ( array( 'Chicago', 'London', 'Hamburg', 'Pune', 'Bangalore', 'Shanghai', 'Tokyo', 'Singapore' ) as $peepal_index => $peepal_city ) : ?>
    <li><button class="city" type="button" data-city="<?php echo esc_attr( $peepal_index ); ?>" aria-pressed="false">
      <span class="pip"></span><?php echo esc_html( $peepal_city ); ?>
    </button></li>
    <?php endforeach; ?>
  </ul>

  <div class="plate develop" data-delay="2">
    <canvas class="plate__map" id="worldMap"
            aria-label="<?php esc_attr_e( 'Map of the Bridged Global partner studios across eight cities and three continents', 'peepal-design' ); ?>" role="img"></canvas>
    <div class="plate__reg" aria-hidden="true"><span></span><span></span><span></span><span></span></div>
  </div>
</section>

<section class="frame sec sec--faq" id="faq">
  <div class="edge"><span class="edge__code"><?php esc_html_e( 'COMMON QUESTIONS', 'peepal-design' ); ?></span><span class="edge__ticks"></span></div>
  <div class="sec__intro">
    <h2 class="h2 develop"><?php esc_html_e( 'Frequently asked', 'peepal-design' ); ?> <em><?php esc_html_e( 'questions', 'peepal-design' ); ?></em></h2>
  </div>
  <div class="lightbox">
    <?php
    $peepal_faqs = array(
        array(
            __( 'What makes Peepal Design different from other UX agencies?', 'peepal-design' ),
            __( 'We start from primary evidence, not from a template. Every engagement begins with fieldwork (interviews, observation, behavioural analysis), and the design that follows is traceable back to what we saw. Fifteen years and 10,000+ interviews mean we bring pattern knowledge as well as fresh research.', 'peepal-design' ),
        ),
        array(
            __( 'How long does a typical UX research project take?', 'peepal-design' ),
            __( 'A focused discovery study runs four to six weeks. A full research-and-design engagement typically runs three to five months, depending on the number of user segments and markets involved. We scope in phases so you get usable findings early rather than one report at the end.', 'peepal-design' ),
        ),
        array(
            __( 'Do you work with international clients?', 'peepal-design' ),
            __( 'Yes. We operate across nine cities on three continents and are part of Bridged Global, a worldwide network of UX studios. That gives us native-language researchers and in-market recruitment in most regions our clients need.', 'peepal-design' ),
        ),
        array(
            __( 'Can you do both research and design for the same project?', 'peepal-design' ),
            __( 'That is our preferred model. When the team that ran the interviews also draws the screens, insight survives the handoff intact. We can also plug into your existing design team as the research function alone.', 'peepal-design' ),
        ),
        array(
            __( 'What is LEGO® Serious Play and how can it help?', 'peepal-design' ),
            __( 'It is a facilitated workshop method where participants build models to think through a problem, then explain what they built. It surfaces assumptions that stay hidden in ordinary discussion, and it is unusually effective at getting a divided stakeholder group to a shared position quickly.', 'peepal-design' ),
        ),
        array(
            __( 'What industries do you have experience in?', 'peepal-design' ),
            __( 'Enterprise software, industrial and manufacturing systems, consumer AI products, financial services, healthcare, and education technology. Across 1200+ research projects we have worked in most regulated and safety-critical contexts you are likely to be operating in.', 'peepal-design' ),
        ),
        array(
            __( 'Do you offer UX training for in-house teams?', 'peepal-design' ),
            __( 'Yes. UXPM Training, research bootcamps, and LEGO® Serious Play facilitation, delivered on-site or remotely. Programmes are built around your actual product work rather than generic exercises, so teams finish with artefacts they keep using.', 'peepal-design' ),
        ),
        array(
            __( 'How do I get started with Peepal Design?', 'peepal-design' ),
            __( 'Send us the product challenge in a paragraph. We will come back with how we would research it, what that would cost, and how long it would take — before any commitment.', 'peepal-design' ),
        ),
    );
    $peepal_faq_columns = array_chunk( $peepal_faqs, (int) ceil( count( $peepal_faqs ) / 2 ) );
    foreach ( $peepal_faq_columns as $peepal_column ) :
        ?>
    <div class="lightbox__col">
      <?php foreach ( $peepal_column as $peepal_faq_index => $peepal_faq ) : ?>
      <div class="qa develop"<?php echo $peepal_faq_index > 0 ? ' data-delay="' . esc_attr( $peepal_faq_index ) . '"' : ''; ?>><button class="qa__q" aria-expanded="false"><span><?php echo esc_html( $peepal_faq[0] ); ?></span><svg class="qa__x" viewBox="0 0 16 16" aria-hidden="true"><path d="M8 2v12M2 8h12" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round"/></svg></button><div class="qa__a"><div><p><?php echo esc_html( $peepal_faq[1] ); ?></p></div></div></div>
      <?php endforeach; ?>
    </div>
    <?php endforeach; ?>
  </div>
</section>

<section class="frame sec sec--contact" id="contact">
  <div class="contact__grid">
    <div class="contact__intro">
      <h2 class="contact__h develop"><?php esc_html_e( 'Ready to build something', 'peepal-design' ); ?> <em><?php esc_html_e( 'people love?', 'peepal-design' ); ?></em></h2>
      <p class="contact__p develop" data-delay="1"><?php esc_html_e( "Tell us about your product challenge. We'll tell you exactly how user research should inform the solution — and what that looks like in practice.", 'peepal-design' ); ?></p>
      <div class="contact__act develop" data-delay="2">
        <a class="btn btn--mark" href="#contact"><?php esc_html_e( 'Get in touch', 'peepal-design' ); ?></a>
      </div>
    </div>

    <div class="booker develop" data-delay="2"
         data-cal-link="theghost-writer-wucmfa/30min"
         data-cal-namespace="30min">
      <div class="booker__panel is-loading" id="bookerMount">
        <div class="booker__await">
          <span class="booker__code"><?php esc_html_e( 'Opening the calendar', 'peepal-design' ); ?></span>
        </div>
      </div>
      <div class="booker__cue">
        <svg class="booker__clock" viewBox="0 0 20 20" aria-hidden="true">
          <circle cx="10" cy="10" r="7.4" fill="none" stroke="currentColor" stroke-width="1.5"/>
          <path d="M10 5.6V10l3 1.9" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
        </svg>
        <span class="booker__cue-body">
          <span class="booker__cue-title"><?php esc_html_e( 'Book a 30-minute intro call', 'peepal-design' ); ?></span>
          <span class="booker__cue-note"><?php esc_html_e( 'Pick a time that suits you — no forms, no back-and-forth.', 'peepal-design' ); ?></span>
        </span>
      </div>
      <noscript>
        <p class="booker__noscript"><?php esc_html_e( 'Booking needs JavaScript.', 'peepal-design' ); ?> <a href="#contact"><?php esc_html_e( 'Email us', 'peepal-design' ); ?></a> <?php esc_html_e( "and we'll find a time.", 'peepal-design' ); ?></p>
      </noscript>
    </div>
  </div>
  <div class="contact__strip" aria-hidden="true"></div>
</section>

<?php
endwhile;

get_footer();
