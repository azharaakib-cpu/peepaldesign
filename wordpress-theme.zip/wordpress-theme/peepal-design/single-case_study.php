<?php
/**
 * Single Case Study. Body sections (brief/challenge/discover/personas/
 * etc.) are the post's own flexible content, authored with the
 * peepal/case-* patterns in inc/block-patterns.php — every section
 * pattern wraps itself in <section id="...">, which is what lets
 * peepal_build_csnav() build the tab bar without a separate field.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

get_header();

while ( have_posts() ) :
	the_post();
	$peepal_rendered = apply_filters( 'the_content', get_the_content() );
	$peepal_csnav    = peepal_build_csnav( $peepal_rendered );
	?>

<article class="frame sec sec--case">
	<?php
	get_template_part(
		'template-parts/crumb',
		null,
		array(
			'label' => __( 'Projects', 'peepal-design' ),
			'url'   => home_url( '/portfolio/' ),
		)
	);
	?>

	<header class="cs__head">
		<h1 class="cs__title develop"><?php the_title(); ?></h1>
		<?php if ( has_excerpt() ) : ?>
		<p class="cs__intro develop" data-delay="1"><?php echo esc_html( get_the_excerpt() ); ?></p>
		<?php endif; ?>
	</header>

	<?php if ( has_post_thumbnail() ) : ?>
	<figure class="cs__hero develop" data-delay="2">
		<?php the_post_thumbnail( 'peepal-hero' ); ?>
	</figure>
	<?php endif; ?>

	<?php echo $peepal_csnav; // phpcs:ignore WordPress.Security.EscapeOutput -- built entirely from esc_attr()/wp_strip_all_tags() output inside peepal_build_csnav(). ?>

	<?php echo $peepal_rendered; // phpcs:ignore WordPress.Security.EscapeOutput -- already passed through the_content filter chain. ?>
</article>

<?php
$peepal_similar_query = false;
$peepal_terms         = get_the_terms( get_the_ID(), 'case_category' );
if ( is_array( $peepal_terms ) && $peepal_terms ) {
	$peepal_similar_query = new WP_Query(
		array(
			'post_type'      => 'case_study',
			'post_status'    => 'publish',
			'posts_per_page' => 3,
			'post__not_in'   => array( get_the_ID() ),
			'tax_query'      => array( // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_tax_query
				array(
					'taxonomy' => 'case_category',
					'field'    => 'term_id',
					'terms'    => wp_list_pluck( $peepal_terms, 'term_id' ),
				),
			),
		)
	);
}

if ( $peepal_similar_query && $peepal_similar_query->have_posts() ) :
	?>
<section class="frame sec sec--more" id="similar">
	<div class="cs">
		<h2 class="cs__label"><?php esc_html_e( 'Similar case studies', 'peepal-design' ); ?></h2>
		<div class="cs__body">
			<p><?php esc_html_e( "Other programmes that share this one's ground.", 'peepal-design' ); ?></p>
		</div>
		<div class="cases cases--three">
			<?php
			$peepal_index = 0;
			while ( $peepal_similar_query->have_posts() ) :
				$peepal_similar_query->the_post();
				++$peepal_index;
				get_template_part(
					'template-parts/case-card',
					null,
					array(
						'prefix' => 'R',
						'index'  => $peepal_index,
					)
				);
			endwhile;
			wp_reset_postdata();
			?>
		</div>
		<p class="more__all"><a class="learn" href="<?php echo esc_url( home_url( '/portfolio/' ) ); ?>"><?php esc_html_e( 'View all case studies', 'peepal-design' ); ?><svg viewBox="0 0 16 10" aria-hidden="true"><path d="M0 5h14M10 1l4 4-4 4" fill="none" stroke="currentColor" stroke-width="1.4" stroke-linecap="round" stroke-linejoin="round"/></svg></a></p>
	</div>
</section>
<?php endif; ?>

<?php get_template_part( 'template-parts/pitch-cta' ); ?>

<?php
endwhile;

get_footer();
