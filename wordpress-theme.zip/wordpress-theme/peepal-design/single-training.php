<?php
/**
 * Single Training programme. No case-studies carousel here — the static
 * training pages never carried one (nutshell/agenda/audience/gains/
 * trainers, in whatever combination each programme needs), unlike
 * service pages. Otherwise the same shape as single-service.php: fixed
 * header/hero/pitch around a fully flexible post_content body.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

get_header();

while ( have_posts() ) :
	the_post();
	$peepal_intro = get_post_meta( get_the_ID(), 'peepal_intro', true );
	?>

<article class="frame sec sec--case">
	<nav class="cs__crumb" aria-label="Breadcrumb">
		<a href="<?php echo esc_url( home_url( '/' ) ); ?>"><?php esc_html_e( 'Home', 'peepal-design' ); ?></a> <span aria-hidden="true">/</span>
		<span aria-current="page"><?php the_title(); ?></span>
	</nav>

	<header class="cs__head">
		<h1 class="cs__title develop"><?php the_title(); ?></h1>
		<?php if ( $peepal_intro ) : ?>
		<p class="cs__intro develop" data-delay="1"><?php echo esc_html( $peepal_intro ); ?></p>
		<?php endif; ?>
		<div class="cs__acts develop" data-delay="2">
			<a class="btn btn--mark" href="<?php echo esc_url( home_url( '/#contact' ) ); ?>"><?php esc_html_e( 'Get in touch', 'peepal-design' ); ?></a>
		</div>
	</header>

	<?php if ( has_post_thumbnail() ) : ?>
	<figure class="cs__hero cs__hero--full develop" data-delay="2">
		<?php the_post_thumbnail( 'peepal-hero' ); ?>
	</figure>
	<?php endif; ?>

	<?php the_content(); ?>

	<?php get_template_part( 'template-parts/pitch-cta' ); ?>
</article>

<?php
endwhile;

get_footer();
