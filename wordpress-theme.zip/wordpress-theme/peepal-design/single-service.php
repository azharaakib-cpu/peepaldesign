<?php
/**
 * Single Service page. Everything between the hero and the case-studies
 * carousel is the post's own flexible content (definition/why/principles/
 * demo/faq sections, authored with the patterns in inc/block-patterns.php)
 * — this template only supplies the parts that sit outside that flow:
 * breadcrumb, title/intro/CTA header, hero image, the carousel, and the
 * closing pitch.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

get_header();

while ( have_posts() ) :
	the_post();
	$peepal_intro = get_post_meta( get_the_ID(), 'peepal_intro', true );
	?>

<article class="frame sec sec--case">
	<?php
	get_template_part(
		'template-parts/crumb',
		null,
		array(
			'label' => __( 'Our Services', 'peepal-design' ),
			'url'   => home_url( '/#services' ),
		)
	);
	?>

	<header class="cs__head">
		<h1 class="cs__title develop"><?php the_title(); ?></h1>
		<?php if ( $peepal_intro ) : ?>
		<p class="cs__intro develop" data-delay="1"><?php echo esc_html( $peepal_intro ); ?></p>
		<?php endif; ?>
		<div class="cs__acts develop" data-delay="2">
			<a class="btn btn--mark" href="<?php echo esc_url( home_url( '/#contact' ) ); ?>"><?php esc_html_e( 'Test your product', 'peepal-design' ); ?></a>
		</div>
	</header>

	<?php if ( has_post_thumbnail() ) : ?>
	<figure class="cs__hero cs__hero--full develop" data-delay="2">
		<?php the_post_thumbnail( 'peepal-hero' ); ?>
	</figure>
	<?php endif; ?>

	<?php
	list( $peepal_body, $peepal_faq ) = peepal_split_content_faq( apply_filters( 'the_content', get_the_content() ) );
	echo $peepal_body; // phpcs:ignore WordPress.Security.EscapeOutput -- already passed through the_content filter chain (wpautop/do_blocks/etc.), same trust level as calling the_content() directly.
	?>

	<?php get_template_part( 'template-parts/case-carousel' ); ?>

	<?php get_template_part( 'template-parts/pitch-cta' ); ?>
</article>

<?php
echo $peepal_faq; // phpcs:ignore WordPress.Security.EscapeOutput -- see note above; direct child of <main> to match contact-sheet.css's `main > #faq:last-child` selector.

endwhile;

get_footer();
