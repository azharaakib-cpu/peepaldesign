# Peepal Design — WordPress theme

Ported from the hand-built static site at the repo root. Full architecture rationale lives in the plan this was built from; the short version:

- **Classic PHP theme**, not a block/FSE theme — the static site's JS queries very specific markup and data-attributes, which a classic theme can reproduce exactly.
- **No ACF, no plugin dependencies.** Content that varies section-to-section (service pages, case studies, training pages) is authored with the native block editor plus a set of Block Patterns that insert pre-classed sections — no premium plugin required to run this theme.
- Small fixed-shape content (testimonials, client logos, offices, job openings) is its own Custom Post Type with a couple of plain meta fields. Team/trainer photo grids turned out to need a *different curated lineup on every page* (Our Journey's leaders vs. each Training's own trainers), so those are a Block Pattern instead of a CPT — a CPT would have implied "the same list everywhere," which isn't true here.

## ⚠️ Not tested on a live WordPress install

This theme was written on a machine with no PHP interpreter and no WP-CLI available — **none of this code has actually been executed.** Every file has been hand-reviewed against WordPress core APIs, and every `<?php ?>` region in every file has been run through a purpose-built string/quote-boundary scanner (tracks single- and double-quoted strings, backslash escapes, and comments, to catch unterminated strings a casual read would miss) — but that's static analysis, not execution. Before using this anywhere real:

1. Install it on a local WordPress environment (e.g. [Local](https://localwp.com/), `wp-env`, MAMP, or your host's staging site).
2. Activate it, click through every page type, and check the browser console for JS errors.
3. Only then treat it as production-ready.

## Install

1. Zip this folder (or copy it) into `wp-content/themes/peepal-design/`.
2. Activate **Peepal Design** under Appearance → Themes.
3. Settings → Reading: set a static page as the front page (for `front-page.php`, added in Phase 8) and set a "Blog" page as the Posts page — that routes to `home.php`.
4. Create these Pages and assign the matching template under Page Attributes → Template:
   - `portfolio` → **Portfolio**
   - `careers` → **Careers**
   - `our-journey` → **Our Journey**
   - `our-global-family` → **Our Global Family**
5. Create at least the `mobile`, `ux-design` case-study category terms (Case Studies → Categories) before importing the sample content below, since it assigns them.
6. Two ready-to-use content examples are in `sample-content/` — each file's own header comment explains exactly what to create and where to paste it:
   - `service-usability-testing.blocks.html` → a "Service" post.
   - `case-mera-bajaj.blocks.html` → a "Case Study" post.

## Progress against the migration plan

- [x] **Phase 1 — skeleton.** Theme bootstrap, `theme.json`, `header.php`/`footer.php` (mega-menu + footer ported, active-nav-state via `peepal_nav_is_here()` in `inc/template-tags.php`), asset enqueueing (`contact-sheet.css` + `main.js` ported byte-for-byte, cache-busted by file modification time instead of a hand-maintained `?v=`).
- [x] **Phase 2 — `service` CPT.** `inc/cpt-service.php`, 4 Block Patterns for the flexible body (`inc/block-patterns.php`: definition grid, why-paragraphs, numbered principles, FAQ), `single-service.php`, and `sample-content/service-usability-testing.blocks.html` as the real worked example.
- [x] **Phase 3 — `case_study` CPT.** `inc/cpt-case-study.php`, 4 more Block Patterns for case-study bodies (text, text+image, two-column, persona grid), `page-portfolio.php` (filter chips built from live `case_category` terms), `single-case_study.php` (auto-built section tab bar via `peepal_build_csnav()`, "Similar case studies" queried by shared category), `template-parts/case-card.php` shared by both, and `sample-content/case-mera-bajaj.blocks.html`.
- [x] **Phase 4 — Blog.** Native `post` type. `home.php` (listing — runs its own query rather than the main one, same reasoning as page-portfolio.php, so the existing client-side filter/search/pager JS keeps working against a fully-rendered card list), `single.php` (auto-built table of contents via `peepal_build_toc()`, reading Heading blocks' native "Anchor" field — no custom field needed), `template-parts/author-box.php` (the static site's byline is the studio itself, not a WP user, so this is intentionally not wired to per-author fields), `peepal_read_time()` replacing the old hand-typed "X min read".
- [x] **Phase 5 — Careers.** `inc/cpt-job-opening.php` (+ `job_function` taxonomy), `page-careers.php` — hero carousel and the "Peepal advantage"/"application process" sections are hardcoded (fixed brand messaging, not exposed as fields, same reasoning as Our Journey's narrative content), the jobs grid and the hidden per-job `<template>` elements the modal script reads are genuinely dynamic. The job-detail modal + apply form have no backend on the static site (a deliberate, documented choice there) and are reproduced exactly as inert — no submission handler was added.
- [x] **Phase 6 (partial) — `training` CPT + `single-training.php`.** Same flexible-body approach as Service, minus the case-studies carousel (the static training pages never had one) and minus the FAQ-splitting logic (none of the 3 training pages has a FAQ section). **The other 15 service pages and 3 training pages are not yet migrated as content** — see "What's left" below; the templates that render them already exist and don't need further engineering, only content authored through them.
- [x] **Phase 7 — one-off pages + supporting CPTs.** `page-our-journey.php`, `page-our-global-family.php` (+ `inc/cpt-office.php` and `template-parts/office-grid.php` for its "cities" grid), `inc/cpt-testimonial.php`, `inc/cpt-client-logo.php`, `template-parts/hero-carousel.php` (shared by Careers and Our Journey — extracted after noticing both pages used the identical `.peek` carousel), 3 more Block Patterns (`section-header-only`, `section-header-body`, `crew-grid`).
- [x] **Phase 8 — `front-page.php`.** See "How the homepage differs from every other template" below for what's dynamic vs. deliberately hardcoded, and why.

## How the homepage differs from every other template

Every other page's dynamic behaviour has been "loop over some posts and print markup" — safe to write without a live browser. Two of the homepage's JS modules are different: the *shape and count* of the markup itself drives scroll-math they compute at runtime. I read both modules in `main.js` before deciding what to make dynamic:

- **World map (`THE PLATE`)**: keeps its own hand-tuned `CITIES` array *inside `main.js`* — lat/lon plus per-city label-nudge pixel offsets (`lx`/`ly`/`al`) that were manually tuned for the canvas render. There's no way for a content editor filling in "Chicago" to also supply correct label-nudge offsets, and re-deriving this JS array from PHP with no browser to check the canvas against was the one thing in this whole project I judged not worth the risk. **The map, the 8-item city tag list, and the citycard panel are ported byte-for-byte and stay wired to `main.js`'s existing internal data — nothing here is CMS-editable.** If you need to add/remove/rename a city, that's a `main.js` edit, not a wp-admin one.
- **Services teaser (`SERVICES PIN`)**: pairs each `.svc__item` to a `.svc__shot` by a `data-svc` index. Hardcoded (matches Careers' identical "advantage" section) rather than turned into fields, since four items that rarely change didn't seem worth a field UI.
- **Clients logo wall (`CLIENTS REEL`) and the stat counter (`EXPOSURE COUNTER`)** were the reassuring finds: both are genuinely index-agnostic in the JS (`CLIENTS REEL` measures however many `[data-clients-track]` rows exist and however many `.client-cell` items are in each; the counter just reads `data-count`/`data-suffix` off however many `.counter__n` elements are present). That made them safe to wire up for real — see the Content-authoring guide below.
- **Hero H1**: frozen, client-approved copy (see the project's own PRODUCT.md) with `<span class="tok tok--human/ai">` colour-coding baked onto specific words ("human", "AI"). A plain text field can't preserve that markup safely, so the headline stays hardcoded; only the sub-copy and the 4 stat counters became fields.
- **FAQ and Contact/Cal.com sections**: hardcoded, matching their static-site reality (FAQ copy doesn't recur elsewhere the way service/case-study content does; the Cal.com link is a fixed embed, unrelated to content).

## What's deliberately excluded from `assets/`

The site's `assets/img/services/` folder on the static site carries ~130MB of source PDFs (client-provided documents that copy was transcribed from) plus `_source/`, `Banners/`, and `placeholders/` subfolders. None of these are ever linked from a live page — they're only referenced in code comments as provenance notes — so they were not copied into this theme. Only the 4 real promo images (`design.jpg`, `research.jpg`, `strategy.jpg`, `training.jpg`) came across. Same for `assets/img/work/bg.png` (9.7MB, unreferenced) and every `_source/` folder.

## Content-authoring guide (fill in as CPTs are added)

### Services (`service` post type)
- **Title**, **featured image** (the full-bleed hero banner), and the **Intro paragraph** / **Closing CTA** fields in the "Service page details" box are the only real fields.
- Everything else — definition grid, why-paragraphs, numbered principles, demo/chart sections, FAQ — is the post's own content. Use **+ (Add block) → Patterns → Peepal Design sections** to insert a ready-made section, then edit the text inside it. Patterns insert as a "Custom HTML" block: what you see in the visual editor is the rendered HTML, and editing it means changing the text between the tags directly (there's no separate rich-text field per line) — this trades a little editing convenience for guaranteed pixel-perfect markup, since none of this has been checked against a live block editor yet.
- The "Case studies" carousel and the closing pitch section at the bottom of every service page are rendered by the theme automatically — don't add them to the content.

### Case Studies (`case_study` post type)
- **Excerpt** = the short description shown on cards. **Featured image** = the card thumbnail / page hero.
- "Case study card details": **Kicker/code** (the small eyebrow label), **Carousel monogram** (hand-picked 2-letter mark — see the field description for why this isn't auto-generated), **Show in the case studies carousel** (check this on whichever 4-ish case studies should appear in the reused-everywhere carousel on service/training pages), **Placeholder card** (check this for a case study you haven't written yet — its card links to the contact section instead of a thin page).
- Body content uses the **Peepal Design sections** patterns same as Services: Text, Text + image, Two columns, Persona grid. Give each section's `<section id="...">` a unique id — the in-page tab bar at the top of the case study is built automatically from those ids and their `<h2 class="cs__label">` text.
- Assign **Case Study Categories** (the taxonomy terms double as the portfolio page's filter chips and drive "Similar case studies").

### Portfolio listing
Just a Page (slug `portfolio`, template "Portfolio") — no content to author on the page itself beyond an optional excerpt for the hero subhead. The grid and filter chips are entirely generated from published Case Study posts and their categories.

### Blog (native Posts)
Ordinary WordPress posts: **Title**, **Excerpt** (the dek/summary shown on cards and at the top of the article), **Featured image**, **Category** (drives both the filter chips and the meta tag), and freeform block-editor **content**. To have a heading appear in the article's auto-built table of contents, select the Heading block and set an **HTML Anchor** in the block's Advanced panel (sidebar) — no special pattern needed. Set Settings → Reading → "Posts page" to make `home.php` the listing.

### Training (`training` post type)
Same authoring model as Services: **Title**, **featured image**, **Intro paragraph** / **Closing CTA** fields, flexible `post_content` built from the same Peepal Design section patterns plus **Team / trainer photo grid** for a trainer lineup and the FAQ pattern's `.qa` markup (add a `qa--mod` class by hand) for an agenda/curriculum accordion. No case-studies carousel is rendered on this template — the static site never had one here.

### Careers, Our Journey, Our Global Family
These are Pages with a specific template assigned (see Install above). Careers' hero carousel/advantage-cards/hiring-process content and Our Journey's hero carousel are fixed in the template itself, not editable from wp-admin — they're stable brand messaging, same treatment as the rest of a "one-off narrative page." What *is* editable: the page Title/Excerpt (shown as the `<h1>`/intro), and — for Our Journey — the flexible body (About/Values/Beliefs/Leaders sections via patterns). Our Global Family's body is flexible content too, with its "cities" office grid always rendered directly after it (pulled from the Office post type, ordered by drag-and-drop under Page Attributes — logo is the featured image, city name is the Title, the one-sentence description is the editor content, and "Website link" is a field).

### Job Openings (`job_opening` post type)
**Title**, **Excerpt** (the one-line summary on the card), **Location** / **Experience range** fields, **Job Function** taxonomy term (drives the careers page's filter chips — create terms matching the static site's five: Design, Research, Business & Marketing, UX Writing, HR), and `post_content` authored with the **Job opening: full description** pattern for the modal body.

### Testimonials / Client Logos
Both are small CPTs with no single-post page — they only ever render as part of the homepage. Testimonial: **Title** (unused for display), editor content = the quote, featured image = organisation logo, plus Name/Role/Rating fields. Client Logo: **Title** = client name (used as alt text and as the text fallback if the logo image is missing), featured image = the logo file. Order both via drag-and-drop under Page Attributes — for Client Logo specifically, the reel splits them into two rows down the middle of however many are published, so the split point moves as you add or remove logos.

### Homepage (front-page.php)
Requires: Settings → Reading → "Your homepage displays" → a static page, set to whichever Page you create for it.
- **"Homepage hero & stats" box** (only appears on the page assigned as the front page): hero sub-copy paragraph, and 4 stat-counter Value/Suffix/Label triples. The H1 itself is not editable here — see the note above on why.
- **"Work" grid**: 4 Case Study posts with **Show in the homepage "Work" grid** checked, plus an optional **Homepage client name** (falls back to the post title if blank) shown in all-caps on the card. One deliberate deviation from the static markup: "View Case Study" is now a real link to the post's permalink (`<a>`), where the static site left it as inert decorative text (`<span>`, no href) since those 4 showcase cards never had real detail pages to link to — now that they can, linking them seemed like the obviously-intended behaviour rather than a static-markup detail worth preserving.
- **Clients wall, Testimonials**: entirely from the Client Logo / Testimonial post types — nothing to configure on the homepage itself beyond publishing them.
- Everything else on this page (services teaser, world map/city list, FAQ, Cal.com contact section) is fixed template content, not editable from wp-admin — see the note above for which parts and why.
